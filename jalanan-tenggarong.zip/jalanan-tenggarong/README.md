# Jalanan Tenggarong

Game 3D santai menyusuri tepian Sungai Mahakam, Tenggarong, Kutai Kartanegara.
Gaya endless-runner ala Subway Surfers, tetapi tanpa game over: menabrak hanya memperlambat laju.

![thumbnail](resources/thumbnail.png)

## Fitur
- 30 level bernama (Tepian Mahakam, Jembatan Kartanegara, Pulau Kumala, dst.), waktu berganti dari fajar, siang, sore, senja, sampai malam berbintang
- Jembatan Kartanegara berlengkung, sungai bergelombang, tongkang dan perahu, burung, awan, patung Pesut
- Mode portrait (paling nyaman dimainkan satu tangan di HP), landscape juga didukung
- Musik latar dari file yang Anda kirim, bisa dimatikan lewat tombol speaker
- Mesin 3D WebGL buatan sendiri, tanpa pustaka luar, ringan untuk 60 FPS

## Kontrol
- Geser kiri / kanan: pindah jalur
- Geser ke atas atau ketuk: lompat (melewati palang dan kerucut)
- Keyboard: panah / A D / spasi

## Cara membuat APK (otomatis di GitHub)
1. Buat repository baru di GitHub, lalu upload seluruh isi folder ini (termasuk folder `.github`).
2. Buka tab **Actions** > **Build APK Android** > **Run workflow** (atau cukup push ke branch `main`).
3. Tunggu sekitar 5-8 menit, lalu unduh **Jalanan-Tenggarong-APK** dari bagian *Artifacts* di bawah hasil build.
4. Ekstrak zip-nya, kirim `app-debug.apk` ke HP, dan install (izinkan "install dari sumber tidak dikenal").

## Main lewat browser tanpa APK
Jalankan workflow **Main di Browser (GitHub Pages)** (aktifkan dulu Settings > Pages > Source: GitHub Actions). Buka link-nya di Chrome HP, lalu pilih "Tambahkan ke layar utama".

## Uji di komputer
```
npm start    # lalu buka http://localhost:8080
```

## Struktur
- `www/` : game (index.html, gl.js mesin 3D, world.js dunia, props.js objek, game.js logika, assets/music.mp3)
- `assets/` : ikon adaptif dan splash untuk Android
- `.github/workflows/` : build APK dan GitHub Pages
