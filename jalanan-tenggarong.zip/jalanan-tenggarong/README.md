# Jalanan Tenggarong

Game 3D santai menyusuri tepian Sungai Mahakam, Tenggarong, Kutai Kartanegara.
Gaya endless-runner ala Subway Surfers, tetapi tanpa game over: menabrak hanya memperlambat laju.

![thumbnail](resources/thumbnail.png)

## Fitur
- Karakter pemain: **pelari** beranimasi (kaki, lengan, lompat, bersorak)
- **30 level** bernama; kecepatan lari naik tiap level (Level 1 = 70 km/j (1.000 m) sampai Level 30 = 500 km/j (7.000 m)), langit/waktu berganti halus tanpa lompatan grafik
- Gapura garis finis hitam-putih di akhir tiap level
- **3 hati**: tertabrak = hati berkurang; hati habis = mengulang dari level terakhir yang sedang dimainkan
- **Koin** emas dua sisi, berputar, selalu terang (jelas juga di malam hari); koin tersimpan di dompet
- **Toko Aksesori**: helm, baju, jaket, celana, sepatu, sayap di punggung (beli dengan koin, lalu pakai; pratinjau 3D berputar)
- **Perayaan tiap level selesai**: stiker jempol + orang lucu tersenyum, dialog ala komik "Ku akui, ndik te apai awak memang hebat!", diiringi instrumen perayaan (terompet, drum, rebana, xilofon) + bonus koin
- **4 lagu latar** (Aku Menyanyi, Nasib Awak, Begenjoh, + musik asli) diputar bergantian; tombol ⏭ untuk ganti lagu, speaker untuk senyap
- Mesin 3D WebGL buatan sendiri, tanpa pustaka luar

## Kontrol
- Geser kiri / kanan: pindah jalur
- Geser ke atas atau ketuk: lompat (melewati palang dan kerucut)
- Keyboard: panah / A D / spasi

## Cara membuat APK (otomatis di GitHub)
1. Buat repository baru di GitHub, lalu upload seluruh isi folder ini (termasuk folder `.github`).
2. Buka tab **Actions** > **Build APK Android** > **Run workflow** (atau cukup push ke branch `main`).
3. Tunggu sekitar 5-8 menit, lalu unduh **Jalanan-Tenggarong-APK** dari bagian *Artifacts* di bawah hasil build.
4. Ekstrak zip-nya, kirim `app-debug.apk` ke HP, dan install (izinkan "install dari sumber tidak dikenal").

## Main lewat browser tanpa APK
Jalankan workflow **Main di Browser (GitHub Pages)** (aktifkan dulu Settings > Pages > Source: GitHub Actions). Buka link-nya di Chrome HP, lalu pilih "Tambahkan ke layar utama".

## Uji di komputer
```
npm start    # lalu buka http://localhost:8080
```

## Struktur
- `www/` : game (index.html, gl.js mesin 3D, world.js dunia, props.js objek, game.js logika, assets/*.mp3 = 4 lagu)
- `assets/` : ikon adaptif dan splash untuk Android
- `.github/workflows/` : build APK dan GitHub Pages
