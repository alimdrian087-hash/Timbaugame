/* Dunia: jalan tepi Sungai Mahakam, Tenggarong, jembatan lengkung, tepian sungai */
'use strict';
const CHUNK_L = 60;
const LANES = [-2.4, 0, 2.4];

function rng(seed) { let s = seed >>> 0 || 1; return () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; }; }

function addPalm(mb, x, z, r, h) {
  const trunk = [0.5 + r() * 0.08, 0.38, 0.26];
  const lean = (r() - 0.5) * 0.8, segs = 4;
  let px = x, pz = z, py = 0;
  for (let i = 0; i < segs; i++) {
    const sh = h / segs, w0 = 0.34 - i * 0.04, w1 = 0.34 - (i + 1) * 0.04;
    mb.cyl(px, py, pz, w0, w1, sh, trunk, 6); px += lean * 0.25; py += sh;
  }
  const lc = [0.2 + r() * 0.1, 0.5 + r() * 0.15, 0.2];
  for (let k = 0; k < 8; k++) {
    const a = k / 8 * Math.PI * 2 + r() * 0.3, dx = Math.cos(a), dz = Math.sin(a), len = 2.6 + r() * 0.6;
    const t = [dz * 0.35, 0, -dx * 0.35];
    const b = [px, py, pz], m = [px + dx * len * 0.6, py + 0.9, pz + dz * len * 0.6], e = [px + dx * len, py - 0.6, pz + dz * len];
    mb.quad([b[0] - t[0], b[1], b[2] - t[2]], [b[0] + t[0], b[1], b[2] + t[2]], [m[0] + t[0] * 1.6, m[1], m[2] + t[2] * 1.6], [m[0] - t[0] * 1.6, m[1], m[2] - t[2] * 1.6], lc, [0, 1, 0]);
    mb.quad([m[0] - t[0] * 1.6, m[1], m[2] - t[2] * 1.6], [m[0] + t[0] * 1.6, m[1], m[2] + t[2] * 1.6], [e[0] + t[0] * 0.2, e[1], e[2] + t[2] * 0.2], [e[0] - t[0] * 0.2, e[1], e[2] - t[2] * 0.2], [lc[0] * .8, lc[1] * .85, lc[2]], [0, 1, 0]);
    mb.quad([b[0] + t[0], b[1], b[2] + t[2]], [b[0] - t[0], b[1], b[2] - t[2]], [m[0] - t[0] * 1.6, m[1], m[2] - t[2] * 1.6], [m[0] + t[0] * 1.6, m[1], m[2] + t[2] * 1.6], [lc[0] * .6, lc[1] * .6, lc[2] * .6], [0, -1, 0]);
  }
  mb.sphere(px, py - 0.15, pz, 0.28, 0.28, 0.28, [0.4, 0.28, 0.12], 5);
}

function addTree(mb, x, z, r, s) {
  mb.cyl(x, 0, z, 0.25 * s, 0.15 * s, 2.2 * s, [0.4, 0.3, 0.22], 5);
  const g = 0.28 + r() * 0.15;
  mb.sphere(x, 3.2 * s, z, 1.9 * s, 1.5 * s, 1.9 * s, [0.2, g + 0.2, 0.18], 6);
  mb.sphere(x + 0.8 * s, 2.6 * s, z + 0.4 * s, 1.3 * s, 1.1 * s, 1.3 * s, [0.24, g + 0.15, 0.2], 5);
}

function addLamp(mb, x, z, side, gl) {
  const c = [0.28, 0.3, 0.33];
  mb.cyl(x, 0, z, 0.12, 0.08, 6.4, c, 6);
  mb.box(x - side * 0.9, 6.3, z, 1.9, 0.12, 0.12, c);
  mb.box(x - side * 1.8, 6.15, z, 0.8, 0.14, 0.34, [0.95, 0.9, 0.75]);
  if (gl) { gl.sphere(x - side * 1.8, 6.0, z, 0.55, 0.3, 0.55, [1, 0.92, 0.65], 5); gl.sphere(x - side * 1.8, 5.9, z, 0.8, 0.5, 0.8, [1, 0.85, 0.5], 5); }
}

function addHouse(mb, x, z, r, w, d) {
  const walls = [[0.93, 0.9, 0.8], [0.88, 0.75, 0.55], [0.9, 0.62, 0.45], [0.78, 0.86, 0.9]][(r() * 4) | 0];
  const h = 3.4 + r() * 1.4;
  mb.box(x, 0.9, z, w, h, d, walls);
  mb.box(x, 0, z, w + 0.2, 0.9, d + 0.2, [0.45, 0.35, 0.28]);
  const roof = [0.72, 0.28, 0.2];
  mb.box(x, 0.9 + h, z, w + 1.2, 0.18, d + 1.2, roof, [1, .85, .9, .7]);
  mb.box(x, 1.08 + h, z, w * 0.7, 0.9, d + 0.8, roof, [1, .85, .9, .7]);
  mb.box(x - w / 2 - 0.01, 1.8, z, 0.05, 1.5, d * 0.35, [0.25, 0.2, 0.15]);
  mb.box(x - w / 2 - 0.02, 2.4, z + d * 0.28, 0.06, 1.0, 0.9, [0.55, 0.75, 0.85]);
}

function buildRoadChunk(seed, glow) {
  const r = rng(seed * 7919 + 13), mb = new MeshBuilder(), L = CHUNK_L, z0 = -L, z1 = 0;
  const asp = [0.34, 0.35, 0.38], asp2 = [0.3, 0.31, 0.34];
  // jalan aspal dua lapis agar sedikit bervariasi
  mb.quad([-4.2, 0, z1], [4.2, 0, z1], [4.2, 0, z0], [-4.2, 0, z0], asp, [0, 1, 0]);
  for (let i = 0; i < 3; i++) mb.quad([-4.2, 0.005, z1 - i * 20 - 2], [4.2, 0.005, z1 - i * 20 - 2], [4.2, 0.005, z1 - i * 20 - 12], [-4.2, 0.005, z1 - i * 20 - 12], asp2, [0, 1, 0]);
  // marka putus-putus & garis tepi kuning (khas foto)
  for (const lx of [-1.2, 1.2]) for (let z = 0; z > -L; z -= 6) mb.quad([lx - 0.07, 0.02, z], [lx + 0.07, 0.02, z], [lx + 0.07, 0.02, z - 3], [lx - 0.07, 0.02, z - 3], [0.95, 0.95, 0.92], [0, 1, 0]);
  for (const ex of [-3.9, 3.9]) mb.quad([ex - 0.06, 0.02, z1], [ex + 0.06, 0.02, z1], [ex + 0.06, 0.02, z0], [ex - 0.06, 0.02, z0], [0.95, 0.95, 0.9], [0, 1, 0]);
  // trotoar + kerb hitam-putih
  for (const s of [-1, 1]) {
    for (let z = 0; z > -L; z -= 1.5) {
      const c = ((z / -1.5) | 0) % 2 ? [0.08, 0.08, 0.09] : [0.95, 0.95, 0.95];
      mb.box(s * 4.4, 0, z - 0.75, 0.6, 0.28, 1.5, c);
    }
    mb.box(s * 5.9, 0, -L / 2, 2.4, 0.22, L, [0.72, 0.68, 0.62]);
  }
  // sisi kanan: kuning median taman, rumput, semak, pohon, palem
  mb.box(8.5, 0, -L / 2, 4.2, 0.12, L, [0.3, 0.62, 0.25]);
  mb.box(18, -0.2, -L / 2, 22, 0.3, L, [0.34, 0.6, 0.27]);
  mb.box(36, -0.2, -L / 2, 16, 0.4, L, [0.28, 0.52, 0.24]);
  for (let z = -2; z > -L; z -= 3.2) {
    mb.box(7.5, 0.1, z, 1.1, 0.8, 3, [0.18, 0.5, 0.2]);
    if (r() > 0.4) mb.sphere(7.5 + (r() - 0.5) * 0.6, 0.95, z + (r() - 0.5) * 2, 0.2, 0.18, 0.2, [0.98, 0.85, 0.22], 4);
  }
  for (let z = -6; z > -L; z -= 15) { addPalm(mb, 9.2 + r() * 0.8, z - r() * 3, r, 6 + r() * 3); addLamp(mb, 6.5, z - 7.5, 1, glow); }
  for (let z = -4; z > -L; z -= 9) if (r() > 0.2) addTree(mb, 14 + r() * 10, z - r() * 5, r, 1 + r() * 0.9);
  if (r() > 0.35) addHouse(mb, 18 + r() * 8, -10 - r() * 40, r, 6 + r() * 3, 5 + r() * 3);
  if (r() > 0.55) addHouse(mb, 27 + r() * 6, -10 - r() * 40, r, 6 + r() * 3, 5 + r() * 3);
  // sisi kiri: pagar sungai, tebing landai, tanaman
  const rail = [0.88, 0.88, 0.9];
  for (let z = 0; z > -L; z -= 3) mb.box(-7.15, 0.2, z - 1.5, 0.14, 1.0, 0.14, rail);
  mb.box(-7.15, 1.05, -L / 2, 0.12, 0.12, L, rail); mb.box(-7.15, 0.55, -L / 2, 0.08, 0.08, L, rail);
  for (let z = -6; z > -L; z -= 15) addLamp(mb, -6.4, z - 7.5, -1, glow);
  mb.quad([-7.3, 0, z1], [-7.3, 0, z0], [-8.5, -0.4, z0], [-8.5, -0.4, z1], [0.3, 0.55, 0.25], [0, 1, 0]);
  mb.quad([-8.5, -0.4, z1], [-8.5, -0.4, z0], [-17, -5.2, z0], [-17, -5.2, z1], [0.42, 0.36, 0.26], [0.3, 0.9, 0.2]);
  for (let z = -3; z > -L; z -= 4.5) if (r() > 0.3) mb.sphere(-9.5 - r() * 3, -0.9 - r() * 1.4, z - r() * 2, 0.9, 0.55, 0.9, [0.26, 0.5 + r() * 0.15, 0.22], 5);
  for (let z = -8; z > -L; z -= 22) if (r() > 0.4) addPalm(mb, -9.6 - r() * 2, z, r, 4.5 + r() * 2);
  return mb;
}

/* air sungai: bidang bergelombang (shader) */
function buildWater() {
  const mb = new MeshBuilder(), N = 24, W = 700, D = 700, c = [0.42, 0.4, 0.34], c2 = [0.36, 0.4, 0.4];
  for (let i = 0; i < N; i++) for (let j = 0; j < N; j++) {
    const x0 = -W + i * (W * 2 / N), z0 = -D + j * (D * 2 / N), x1 = x0 + W * 2 / N, z1 = z0 + D * 2 / N;
    mb.quad([x0, -5, z1], [x1, -5, z1], [x1, -5, z0], [x0, -5, z0], (i + j) % 2 ? c : c2, [0, 1, 0]);
  }
  return mb;
}

/* tepian seberang sungai yang jauh (hutan hijau + perbukitan) */
function buildFarBank(seed) {
  const r = rng(seed * 31 + 5), mb = new MeshBuilder(), L = 150;
  mb.box(-330, -5.5, -L / 2, 120, 7, L, [0.3, 0.34, 0.22]);
  for (let i = 0; i < 26; i++) addTree(mb, -270 - r() * 90, -r() * L, r, 2.2 + r() * 2.2);
  for (let i = 0; i < 4; i++) mb.sphere(-420 - r() * 80, -2, -r() * L, 90 + r() * 40, 36 + r() * 24, 70, [0.27, 0.42 + r() * .08, 0.34], 6);
  for (let i = 0; i < 5; i++) addHouse(mb, -262 - r() * 8, -10 - r() * (L - 20), r, 6, 5);
  return mb;
}

/* Jembatan Kartanegara: lengkung baja putih, dek merah-kuning */
function buildBridge() {
  const mb = new MeshBuilder(), steel = [0.78, 0.8, 0.84], red = [0.78, 0.18, 0.15], pier = [0.7, 0.7, 0.72];
  const x0 = -230, x1 = -22, y0 = 9, H = 40, zr = 7, N = 22;
  const archX = i => x0 + (x1 - x0) * i / N, archY = i => y0 + 4 * H * (i / N) * (1 - i / N);
  for (const zz of [-zr, zr]) {
    for (let i = 0; i < N; i++) {
      mb.beam([archX(i), archY(i), zz], [archX(i + 1), archY(i + 1), zz], 1.5, steel);
      mb.beam([archX(i), archY(i) - 1.8, zz], [archX(i + 1), archY(i + 1) - 1.8, zz], 0.5, steel);
      if (i > 0) mb.beam([archX(i), archY(i), zz], [archX(i), y0 + 1, zz], 0.4, steel);
      if (i < N) mb.beam([archX(i), archY(i) - 1.8, zz], [archX(i + 1), archY(i + 1) - 0.1, zz], 0.4, steel);
    }
  }
  for (let i = 3; i < N - 2; i += 2) {
    mb.box(archX(i), archY(i) - 0.6, 0, 1, 1, zr * 2 + 1, steel); // palang melintang atas
  }
  mb.box((x0 + x1) / 2 - 20, y0 - 1.2, 0, x1 - x0 + 90, 1.6, zr * 2 + 3, [0.62, 0.62, 0.64]); // dek
  mb.box((x0 + x1) / 2 - 20, y0 - 1.25, zr + 1.6, x1 - x0 + 90, 0.5, 0.5, red);
  mb.box((x0 + x1) / 2 - 20, y0 - 1.25, -zr - 1.6, x1 - x0 + 90, 0.5, 0.5, red);
  mb.box((x0 + x1) / 2 - 20, y0 + 0.4, 0, x1 - x0 + 90, 0.08, 0.35, [0.95, 0.85, 0.3]); // garis tengah
  for (let i = 0; i <= N; i += 3) mb.box(archX(i), -5, 0, 4, y0 + 3.8, 5, pier);
  mb.box(x1 + 22, -1, 0, 60, y0 + 0.5, zr * 2 + 3, [0.55, 0.55, 0.58]);
  mb.box(x0 - 46, -1, 0, 60, y0 + 0.5, zr * 2 + 3, [0.55, 0.55, 0.58]);
  return mb;
}
