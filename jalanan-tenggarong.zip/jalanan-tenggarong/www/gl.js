/* Mini WebGL 3D engine - tanpa dependensi, ringan untuk 60 FPS di HP */
'use strict';
const M4 = {
  ident() { return new Float32Array([1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1]); },
  persp(fov, asp, n, f) {
    const t = 1 / Math.tan(fov / 2), r = 1 / (n - f), o = new Float32Array(16);
    o[0] = t / asp; o[5] = t; o[10] = (n + f) * r; o[11] = -1; o[14] = 2 * n * f * r; return o;
  },
  mul(a, b) {
    const o = new Float32Array(16);
    for (let i = 0; i < 4; i++) for (let j = 0; j < 4; j++) {
      o[j * 4 + i] = a[i] * b[j * 4] + a[4 + i] * b[j * 4 + 1] + a[8 + i] * b[j * 4 + 2] + a[12 + i] * b[j * 4 + 3];
    }
    return o;
  },
  lookAt(e, c, u) {
    let zx = e[0] - c[0], zy = e[1] - c[1], zz = e[2] - c[2];
    let l = Math.hypot(zx, zy, zz); zx /= l; zy /= l; zz /= l;
    let xx = u[1] * zz - u[2] * zy, xy = u[2] * zx - u[0] * zz, xz = u[0] * zy - u[1] * zx;
    l = Math.hypot(xx, xy, xz); xx /= l; xy /= l; xz /= l;
    const yx = zy * xz - zz * xy, yy = zz * xx - zx * xz, yz = zx * xy - zy * xx;
    return new Float32Array([xx, yx, zx, 0, xy, yy, zy, 0, xz, yz, zz, 0,
      -(xx * e[0] + xy * e[1] + xz * e[2]), -(yx * e[0] + yy * e[1] + yz * e[2]), -(zx * e[0] + zy * e[1] + zz * e[2]), 1]);
  },
  // model = T * Ry * Rx * Rz * S
  model(o, x, y, z, ry, rx, rz, sx, sy, sz) {
    ry = ry || 0; rx = rx || 0; rz = rz || 0; sx = sx == null ? 1 : sx; sy = sy == null ? sx : sy; sz = sz == null ? sx : sz;
    const cy = Math.cos(ry), sY = Math.sin(ry), cx = Math.cos(rx), sX = Math.sin(rx), cz = Math.cos(rz), sZ = Math.sin(rz);
    // R = Ry*Rx*Rz
    const r00 = cy * cz + sY * sX * sZ, r01 = -cy * sZ + sY * sX * cz, r02 = sY * cx;
    const r10 = cx * sZ, r11 = cx * cz, r12 = -sX;
    const r20 = -sY * cz + cy * sX * sZ, r21 = sY * sZ + cy * sX * cz, r22 = cy * cx;
    o[0] = r00 * sx; o[1] = r10 * sx; o[2] = r20 * sx; o[3] = 0;
    o[4] = r01 * sy; o[5] = r11 * sy; o[6] = r21 * sy; o[7] = 0;
    o[8] = r02 * sz; o[9] = r12 * sz; o[10] = r22 * sz; o[11] = 0;
    o[12] = x; o[13] = y; o[14] = z; o[15] = 1; return o;
  }
};

/* Pembangun mesh: posisi, normal, warna per-vertex */
class MeshBuilder {
  constructor() { this.p = []; this.n = []; this.c = []; this.i = []; this.v = 0; }
  tri(a, b, c, col, nrm) {
    let n = nrm;
    if (!n) {
      const ux = b[0] - a[0], uy = b[1] - a[1], uz = b[2] - a[2], vx = c[0] - a[0], vy = c[1] - a[1], vz = c[2] - a[2];
      n = [uy * vz - uz * vy, uz * vx - ux * vz, ux * vy - uy * vx];
      const l = Math.hypot(n[0], n[1], n[2]) || 1; n = [n[0] / l, n[1] / l, n[2] / l];
    }
    for (const q of [a, b, c]) { this.p.push(q[0], q[1], q[2]); this.n.push(n[0], n[1], n[2]); this.c.push(col[0], col[1], col[2]); }
    this.i.push(this.v, this.v + 1, this.v + 2); this.v += 3;
  }
  quad(a, b, c, d, col, nrm) { this.tri(a, b, c, col, nrm); this.tri(a, c, d, col, nrm); }
  // kotak dengan titik pusat alas (x,y,z), lebar w, tinggi h, dalam d
  box(x, y, z, w, h, d, col, shade) {
    const x0 = x - w / 2, x1 = x + w / 2, y0 = y, y1 = y + h, z0 = z - d / 2, z1 = z + d / 2;
    const s = shade || [1, 0.8, 0.9, 0.72];
    const cl = (k) => [col[0] * k, col[1] * k, col[2] * k];
    this.quad([x0, y1, z0], [x0, y1, z1], [x1, y1, z1], [x1, y1, z0], cl(s[0]), [0, 1, 0]);
    this.quad([x0, y0, z1], [x1, y0, z1], [x1, y1, z1], [x0, y1, z1], cl(s[1]), [0, 0, 1]);
    this.quad([x1, y0, z0], [x0, y0, z0], [x0, y1, z0], [x1, y1, z0], cl(s[1]), [0, 0, -1]);
    this.quad([x1, y0, z1], [x1, y0, z0], [x1, y1, z0], [x1, y1, z1], cl(s[2]), [1, 0, 0]);
    this.quad([x0, y0, z0], [x0, y0, z1], [x0, y1, z1], [x0, y1, z0], cl(s[3]), [-1, 0, 0]);
  }
  // silinder tegak (kerucut jika r1 != r0)
  cyl(x, y, z, r0, r1, h, col, seg) {
    seg = seg || 8;
    for (let k = 0; k < seg; k++) {
      const a0 = k / seg * Math.PI * 2, a1 = (k + 1) / seg * Math.PI * 2;
      const am = (a0 + a1) / 2, n = [Math.cos(am), 0.2, Math.sin(am)];
      const sh = 0.75 + 0.25 * Math.cos(am - 0.8);
      const c = [col[0] * sh, col[1] * sh, col[2] * sh];
      const A = [x + Math.cos(a0) * r0, y, z + Math.sin(a0) * r0], B = [x + Math.cos(a1) * r0, y, z + Math.sin(a1) * r0];
      const C = [x + Math.cos(a1) * r1, y + h, z + Math.sin(a1) * r1], D = [x + Math.cos(a0) * r1, y + h, z + Math.sin(a0) * r1];
      this.quad(B, A, D, C, c, n);
      if (r1 > 0) this.tri([x, y + h, z], D, C, [col[0], col[1], col[2]], [0, 1, 0]);
    }
  }
  // bola kasar (ikosahedron-like via lat/long)
  sphere(x, y, z, rx, ry, rz, col, seg) {
    seg = seg || 6;
    const P = (a, b) => [x + Math.cos(a) * Math.sin(b) * rx, y + Math.cos(b) * ry, z + Math.sin(a) * Math.sin(b) * rz];
    for (let i = 0; i < seg; i++) for (let j = 0; j < seg; j++) {
      const a0 = i / seg * Math.PI * 2, a1 = (i + 1) / seg * Math.PI * 2, b0 = j / seg * Math.PI, b1 = (j + 1) / seg * Math.PI;
      const sh = 0.7 + 0.3 * (Math.cos(b0 + 0.1) * 0.5 + 0.5);
      const c = [col[0] * sh, col[1] * sh, col[2] * sh];
      this.quad(P(a0, b0), P(a1, b0), P(a1, b1), P(a0, b1), c);
    }
  }
  // kabel / balok miring antara dua titik
  beam(a, b, t, col) {
    const dx = b[0] - a[0], dy = b[1] - a[1], dz = b[2] - a[2];
    const L = Math.hypot(dx, dy, dz), nx = dx / L, ny = dy / L;
    // tegak lurus pada bidang XY
    const px = -ny * t / 2, py = nx * t / 2, d = t / 2;
    const A0 = [a[0] + px, a[1] + py, a[2] - d], A1 = [a[0] - px, a[1] - py, a[2] - d], A2 = [a[0] - px, a[1] - py, a[2] + d], A3 = [a[0] + px, a[1] + py, a[2] + d];
    const B0 = [b[0] + px, b[1] + py, b[2] - d], B1 = [b[0] - px, b[1] - py, b[2] - d], B2 = [b[0] - px, b[1] - py, b[2] + d], B3 = [b[0] + px, b[1] + py, b[2] + d];
    this.quad(A3, A2, B2, B3, col); this.quad(A0, B0, B1, A1, [col[0] * .85, col[1] * .85, col[2] * .85]);
    this.quad(A0, A3, B3, B0, [col[0] * .95, col[1] * .95, col[2] * .95]); this.quad(A1, B1, B2, A2, [col[0] * .75, col[1] * .75, col[2] * .75]);
  }
}

class Renderer {
  constructor(canvas) {
    const gl = canvas.getContext('webgl', { antialias: true, alpha: false, powerPreference: 'high-performance' }) ||
      canvas.getContext('experimental-webgl');
    if (!gl) throw new Error('WebGL tidak tersedia');
    this.gl = gl; this.canvas = canvas;
    const vs = `attribute vec3 aP;attribute vec3 aN;attribute vec3 aC;
uniform mat4 uVP;uniform mat4 uM;uniform float uTimeV;uniform float uWaterV;
varying vec3 vC;varying vec3 vN;varying float vD;varying vec3 vW;
void main(){
  vec4 w=uM*vec4(aP,1.0);
  if(uWaterV>0.5){ w.y+=sin(w.x*0.35+uTimeV*1.3)*0.05+sin(w.z*0.22+uTimeV*0.9)*0.06; }
  vW=w.xyz; vC=aC; vN=mat3(uM)*aN;
  vec4 p=uVP*w; vD=p.w; gl_Position=p;
}`;
    const fs = `precision mediump float;
varying vec3 vC;varying vec3 vN;varying float vD;varying vec3 vW;
uniform vec3 uSun;uniform vec3 uFog;uniform vec3 uAmb;uniform vec2 uFR;uniform float uWater;uniform float uTime;uniform float uUnlit;uniform float uAlpha;uniform vec3 uCam;uniform float uSky;uniform vec3 uTint;uniform float uSunI;uniform vec3 uTop;uniform vec3 uBot;
void main(){
  if(uSky>0.5){ float h=clamp(normalize(vW-uCam).y,0.0,1.0); gl_FragColor=vec4(mix(uBot,uTop,pow(h,0.55)),1.0); return; }
  vec3 n=normalize(vN);
  float d=max(dot(n,uSun),0.0);
  vec3 c=vC*(uAmb+vec3(1.0,0.95,0.85)*d*uSunI);
  if(uWater>0.5){
    float rip=sin(vW.x*1.7+uTime*1.6)*sin(vW.z*1.1-uTime*1.2);
    c=vC*uAmb*1.5*(0.92+0.12*rip)+vec3(1.0,0.75,0.5)*max(rip,0.0)*0.1*uSunI;
    vec3 vd=normalize(uCam-vW); c+=uFog*pow(1.0-max(vd.y,0.0),4.0)*0.3;
  }
  if(uUnlit>0.5){ c=vC*uTint; }
  float f=clamp((vD-uFR.x)/(uFR.y-uFR.x),0.0,1.0); f=f*f*(3.0-2.0*f);
  gl_FragColor=vec4(mix(c,uFog,f),uAlpha);
}`;
    const sh = (t, s) => { const o = gl.createShader(t); gl.shaderSource(o, s); gl.compileShader(o); if (!gl.getShaderParameter(o, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(o)); return o; };
    const pr = gl.createProgram(); gl.attachShader(pr, sh(gl.VERTEX_SHADER, vs)); gl.attachShader(pr, sh(gl.FRAGMENT_SHADER, fs)); gl.linkProgram(pr);
    if (!gl.getProgramParameter(pr, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(pr));
    gl.useProgram(pr); this.pr = pr;
    this.u = {}; for (const n of ['uVP', 'uM', 'uTime', 'uWater', 'uTimeV', 'uWaterV', 'uSun', 'uFog', 'uAmb', 'uFR', 'uUnlit', 'uAlpha', 'uCam', 'uSky', 'uTop', 'uBot', 'uTint', 'uSunI']) this.u[n] = gl.getUniformLocation(pr, n);
    this.aP = gl.getAttribLocation(pr, 'aP'); this.aN = gl.getAttribLocation(pr, 'aN'); this.aC = gl.getAttribLocation(pr, 'aC');
    gl.enableVertexAttribArray(this.aP); gl.enableVertexAttribArray(this.aN); gl.enableVertexAttribArray(this.aC);
    gl.enable(gl.DEPTH_TEST); gl.enable(gl.CULL_FACE); gl.cullFace(gl.BACK);
    gl.enable(gl.BLEND); gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
    this.idM = M4.ident(); this.big = !!gl.getExtension('OES_element_index_uint');
    this.sun = [0.45, 0.7, 0.35]; { const l = Math.hypot(...this.sun); this.sun = this.sun.map(v => v / l); }
    this.fog = [0.86, 0.78, 0.7]; this.amb = [0.55, 0.55, 0.62]; this.fogR = [40, 190]; this.time = 0; this.cam = [0, 0, 0]; this.sunI = 0.75;
  }
  resize(maxDpr) {
    const dpr = Math.min(window.devicePixelRatio || 1, maxDpr || 1.75);
    const w = Math.floor(window.innerWidth * dpr), h = Math.floor(window.innerHeight * dpr);
    if (this.canvas.width !== w || this.canvas.height !== h) { this.canvas.width = w; this.canvas.height = h; }
    this.gl.viewport(0, 0, w, h); this.aspect = w / h;
  }
  upload(mb) {
    const gl = this.gl, mk = (data, T, Arr) => { const b = gl.createBuffer(); gl.bindBuffer(T, b); gl.bufferData(T, new Arr(data), gl.STATIC_DRAW); return b; };
    const use32 = mb.v > 65535;
    return { p: mk(mb.p, gl.ARRAY_BUFFER, Float32Array), n: mk(mb.n, gl.ARRAY_BUFFER, Float32Array), c: mk(mb.c, gl.ARRAY_BUFFER, Float32Array),
      i: mk(mb.i, gl.ELEMENT_ARRAY_BUFFER, use32 ? Uint32Array : Uint16Array), count: mb.i.length, type: use32 ? gl.UNSIGNED_INT : gl.UNSIGNED_SHORT };
  }
  free(m) { const gl = this.gl; gl.deleteBuffer(m.p); gl.deleteBuffer(m.n); gl.deleteBuffer(m.c); gl.deleteBuffer(m.i); }
  begin(vp, cam) {
    const gl = this.gl, u = this.u; gl.clearColor(this.fog[0], this.fog[1], this.fog[2], 1); gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    gl.uniformMatrix4fv(u.uVP, false, vp); gl.uniform1f(u.uTime, this.time); gl.uniform1f(u.uTimeV, this.time); gl.uniform3fv(u.uSun, this.sun); gl.uniform3fv(u.uFog, this.fog);
    gl.uniform1f(u.uSunI, this.sunI); gl.uniform3fv(u.uAmb, this.amb); gl.uniform2fv(u.uFR, this.fogR); gl.uniform3fv(u.uCam, cam);
    gl.uniform1f(u.uWater, 0); gl.uniform1f(u.uWaterV, 0); gl.uniform1f(u.uUnlit, 0); gl.uniform1f(u.uAlpha, 1); gl.uniform3f(u.uTint, 1, 1, 1);
  }
  sky(m, model, top, bot) {
    const gl = this.gl, u = this.u; gl.depthMask(false); gl.disable(gl.CULL_FACE);
    gl.uniform1f(u.uSky, 1); gl.uniform3fv(u.uTop, top); gl.uniform3fv(u.uBot, bot);
    this.draw(m, model); gl.uniform1f(u.uSky, 0); gl.enable(gl.CULL_FACE); gl.depthMask(true);
  }
  draw(m, model, opt) {
    const gl = this.gl, u = this.u;
    gl.bindBuffer(gl.ARRAY_BUFFER, m.p); gl.vertexAttribPointer(this.aP, 3, gl.FLOAT, false, 0, 0);
    gl.bindBuffer(gl.ARRAY_BUFFER, m.n); gl.vertexAttribPointer(this.aN, 3, gl.FLOAT, false, 0, 0);
    gl.bindBuffer(gl.ARRAY_BUFFER, m.c); gl.vertexAttribPointer(this.aC, 3, gl.FLOAT, false, 0, 0);
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, m.i);
    gl.uniformMatrix4fv(u.uM, false, model || this.idM);
    if (opt) { if (opt.tint) gl.uniform3fv(u.uTint, opt.tint); gl.uniform1f(u.uWater, opt.water ? 1 : 0); gl.uniform1f(u.uWaterV, opt.water ? 1 : 0); gl.uniform1f(u.uUnlit, opt.unlit ? 1 : 0); gl.uniform1f(u.uAlpha, opt.alpha == null ? 1 : opt.alpha); if (opt.noCull) gl.disable(gl.CULL_FACE); }
    gl.drawElements(gl.TRIANGLES, m.count, m.type, 0);
    if (opt) { if (opt.tint) gl.uniform3f(u.uTint, 1, 1, 1); gl.uniform1f(u.uWater, 0); gl.uniform1f(u.uUnlit, 0); gl.uniform1f(u.uAlpha, 1); if (opt.noCull) gl.enable(gl.CULL_FACE); }
  }
}
