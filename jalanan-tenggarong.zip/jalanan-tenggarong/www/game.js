/* Jalanan Tenggarong - game santai di tepi Sungai Mahakam */
'use strict';
(() => {
const $ = id => document.getElementById(id);
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const lerp = (a, b, t) => a + (b - a) * t;
const mix3 = (a, b, t) => [lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t)];

const LEVELS = ['Tepian Mahakam', 'Jembatan Kartanegara', 'Taman Pesut', 'Museum Mulawarman', 'Pulau Kumala', 'Keraton Sultan Kutai',
  'Pasar Tenggarong', 'Kampung Tepian Sungai', 'Dermaga Senja', 'Tugu Pesut', 'Kebun Kelapa Sawit Mini', 'Jalan Pahlawan',
  'Taman Kota Raja', 'Gerbang Kutai', 'Pelabuhan Tongkang', 'Bukit Biru', 'Rumah Panggung', 'Kedai Kopi Tepian',
  'Pelataran Lawang Gada', 'Danau Lipan', 'Sungai Belayan', 'Hutan Kota', 'Menara Pandang', 'Lembah Mahakam',
  'Desa Budaya', 'Sawah Hijau', 'Pelabuhan Lama', 'Tebing Hijau', 'Langit Kutai', 'Puncak Kartanegara'];
const NLEV = 30;
const levelLen = L => 260 + L * 30;

/* ---------- palet waktu (fajar → pagi → siang → sore → senja → malam) ---------- */
const KEYS = [
  { t: 0.00, top: [.42, .52, .78], bot: [.98, .74, .6], amb: [.52, .5, .62], el: .12, si: .55, sc: [1, .7, .5] },
  { t: 0.12, top: [.3, .6, .93], bot: [.86, .93, .98], amb: [.6, .62, .7], el: .45, si: .72, sc: [1, .95, .85] },
  { t: 0.35, top: [.17, .5, .95], bot: [.72, .87, .99], amb: [.66, .68, .74], el: .95, si: .8, sc: [1, 1, .95] },
  { t: 0.55, top: [.32, .5, .84], bot: [.99, .83, .6], amb: [.64, .58, .58], el: .33, si: .7, sc: [1, .8, .55] },
  { t: 0.68, top: [.22, .24, .55], bot: [1, .5, .3], amb: [.5, .42, .55], el: .07, si: .45, sc: [1, .55, .35] },
  { t: 0.80, top: [.03, .05, .17], bot: [.13, .16, .32], amb: [.34, .38, .58], el: .5, si: .22, sc: [.55, .65, 1] },
  { t: 0.92, top: [.1, .14, .33], bot: [.46, .4, .56], amb: [.4, .42, .56], el: .5, si: .25, sc: [.6, .62, .9] },
  { t: 1.00, top: [.42, .52, .78], bot: [.98, .74, .6], amb: [.52, .5, .62], el: .12, si: .55, sc: [1, .7, .5] }];
function palette(t) {
  let i = 0; while (i < KEYS.length - 2 && t > KEYS[i + 1].t) i++;
  const a = KEYS[i], b = KEYS[i + 1], k = clamp((t - a.t) / (b.t - a.t), 0, 1), s = k * k * (3 - 2 * k);
  return { top: mix3(a.top, b.top, s), bot: mix3(a.bot, b.bot, s), amb: mix3(a.amb, b.amb, s), el: lerp(a.el, b.el, s), si: lerp(a.si, b.si, s), sc: mix3(a.sc, b.sc, s) };
}

/* ---------- penyimpanan ---------- */
let save = { unlocked: 1, best: 0, coins: 0 };
try { const s = JSON.parse(localStorage.getItem('jt_save') || 'null'); if (s) save = Object.assign(save, s); } catch (e) {}
const doSave = () => { try { localStorage.setItem('jt_save', JSON.stringify(save)); } catch (e) {} };

/* ---------- renderer & aset ---------- */
const canvas = $('c'); let R;
try { R = new Renderer(canvas); } catch (e) { $('nogl').style.display = 'flex'; throw e; }
R.fogR = [130, 520];
const roadV = [1, 2, 3, 4].map(i => { const g = new MeshBuilder(), m = buildRoadChunk(i, g); return { m: R.upload(m), g: R.upload(g) }; });
const farV = [1, 2, 3].map(i => R.upload(buildFarBank(i)));
const waterM = R.upload(buildWater()), bridgeM = R.upload(buildBridge()), skyM = R.upload(buildSkyDome()), sunM = R.upload(buildSun()), starM = R.upload(buildStars());
const cloudM = [1, 2, 3, 4, 5, 6].map(i => R.upload(buildCloud(i)));
const birdM = [0, 1, 2, 3].map(i => R.upload(buildBird(i)));
const playerM = R.upload(buildPlayer()), pesutM = R.upload(buildPesut());
const carM = [0, 1, 2, 3, 4].map(i => R.upload(buildCar(i))), barrierM = R.upload(buildBarrier()), coneM = R.upload(buildCone()), coinM = R.upload(buildCoin());
const boatM = [R.upload(buildBoat(0)), R.upload(buildBoat(1))];
const shadowM = (() => { const m = new MeshBuilder(); for (let i = 0; i < 10; i++) { const a = i / 10 * 6.2832, b = (i + 1) / 10 * 6.2832; m.tri([0, .03, 0], [Math.cos(b) * .55, .03, Math.sin(b) * 1.15], [Math.cos(a) * .55, .03, Math.sin(a) * 1.15], [0, 0, 0], [0, 1, 0]); } return R.upload(m); })();

/* ---------- audio ---------- */
const music = $('music'); let actx = null, muted = false;
try { const s = localStorage.getItem('jt_muted'); muted = s === '1'; } catch (e) {}
function initAudio() { if (!actx) { try { actx = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) {} } if (actx && actx.state === 'suspended') actx.resume(); }
function playMusic() { music.volume = 0.8; music.muted = muted; const p = music.play(); if (p && p.catch) p.catch(() => {}); }
function tone(f0, f1, dur, type, vol, delay) {
  if (!actx || muted) return; const t = actx.currentTime + (delay || 0), o = actx.createOscillator(), g = actx.createGain();
  o.type = type || 'sine'; o.frequency.setValueAtTime(f0, t); o.frequency.exponentialRampToValueAtTime(Math.max(f1, 1), t + dur);
  g.gain.setValueAtTime(vol || 0.15, t); g.gain.exponentialRampToValueAtTime(0.001, t + dur); o.connect(g); g.connect(actx.destination); o.start(t); o.stop(t + dur + 0.02);
}
const sfx = {
  coin() { tone(988, 988, 0.08, 'sine', 0.13); tone(1319, 1319, 0.16, 'sine', 0.13, 0.07); },
  bump() { tone(180, 50, 0.3, 'triangle', 0.3); },
  jump() { tone(380, 720, 0.14, 'sine', 0.12); },
  level() { [523, 659, 784, 1047].forEach((f, i) => tone(f, f, 0.35, 'sine', 0.13, i * 0.11)); }
};
function setMuted(m) { muted = m; music.muted = m; $('btnMute').textContent = m ? '🔇' : '🔊'; try { localStorage.setItem('jt_muted', m ? '1' : '0'); } catch (e) {} }

/* ---------- status game ---------- */
let state = 'menu', L = 0, lvDist = 0, total = 0, coinsRun = 0, time = 0;
let pz = 0, px = 0, py = 0, vy = 0, speed = 8, lane = 1, tx = 0, bump = 0, shake = 0, lean = 0, camX = 0;
let obs = [], coins = [], nextSpawn = -60, finished = false;
const rnd = Math.random;

function startGame(level) {
  initAudio(); playMusic();
  L = clamp(level, 0, NLEV - 1); lvDist = 0; total = 0; coinsRun = 0; pz = 0; px = 0; tx = 0; lane = 1; py = 0; vy = 0; speed = 8; bump = 0; shake = 0;
  obs = []; coins = []; nextSpawn = -70; finished = false;
  setState('play'); showToast('Level ' + (L + 1), LEVELS[L]);
}
function setState(s) {
  state = s; $('menu').classList.toggle('show', s === 'menu'); $('levels').classList.remove('show'); $('pause').classList.toggle('show', s === 'pause');
  $('hud').classList.toggle('show', s === 'play' || s === 'pause'); $('finale').classList.remove('show');
}
function showToast(a, b) { const t = $('toast'); t.innerHTML = '<b>' + a + '</b><span>' + b + '</span>'; t.classList.remove('go'); void t.offsetWidth; t.classList.add('go'); }

/* ---------- spawn ---------- */
function addCar(lanei, z) { const k = (rnd() * 5) | 0; obs.push({ t: 'car', k, x: LANES[lanei], z, hw: 1.05, hd: k === 4 ? 2.8 : 2.1, h: 1.9, v: 2 + rnd() * 3 }); }
function addBarrier(lanei, z) { obs.push({ t: 'bar', x: LANES[lanei], z, hw: 1.05, hd: 0.3, h: 1.0, v: 0 }); }
function addCones(lanei, z) { for (let i = 0; i < 3; i++) obs.push({ t: 'cone', x: LANES[lanei] + (i - 1) * 0.5, z: z - i * 0.6, hw: 0.38, hd: 0.38, h: 0.9, v: 0 }); }
function addCoins(lanei, z, n, arc) { for (let i = 0; i < n; i++) coins.push({ x: LANES[lanei], z: z - i * 2.3, y: arc ? 0.9 + Math.sin(i / (n - 1) * Math.PI) * 1.2 : 0.9, got: false, ph: rnd() * 6 }); }
function spawnRow(z) {
  const free = [0, 1, 2].sort(() => rnd() - 0.5), r = rnd(), easy = L < 2 ? 0.25 : 0;
  if (r < 0.22 + easy) addCoins(free[0], z, 8, false);
  else if (r < 0.45) { addCar(free[0], z); addCoins(free[1], z + 4, 7, false); }
  else if (r < 0.58 + (L > 4 ? 0.07 : 0)) { addCar(free[0], z); addCar(free[1], z - 4); addCoins(free[2], z + 3, 8, false); }
  else if (r < 0.78) { addBarrier(free[0], z); if (L > 3 && rnd() < 0.5) addBarrier(free[1], z); addCoins(free[0], z + 5, 5, true); }
  else if (r < 0.9) { addCones(free[0], z); addCoins(free[1], z + 3, 6, false); }
  else { addBarrier(free[0], z); addCoins(free[2], z, 9, false); }
}

/* ---------- input ---------- */
function moveLane(d) { if (state !== 'play') return; lane = clamp(lane + d, 0, 2); tx = LANES[lane]; }
function jump() { if (state === 'play' && py <= 0.01) { vy = 9.2; sfx.jump(); } }
window.addEventListener('keydown', e => {
  const k = e.key;
  if (k === 'ArrowLeft' || k === 'a' || k === 'A') moveLane(-1); else if (k === 'ArrowRight' || k === 'd' || k === 'D') moveLane(1);
  else if (k === 'ArrowUp' || k === 'w' || k === 'W' || k === ' ') jump(); else if (k === 'p' || k === 'Escape') togglePause();
});
let t0 = null;
canvas.addEventListener('touchstart', e => { const t = e.changedTouches[0]; t0 = { x: t.clientX, y: t.clientY, t: performance.now(), done: false }; e.preventDefault(); }, { passive: false });
canvas.addEventListener('touchmove', e => {
  if (!t0 || t0.done) return; const t = e.changedTouches[0], dx = t.clientX - t0.x, dy = t.clientY - t0.y;
  if (Math.abs(dx) > 28 && Math.abs(dx) > Math.abs(dy)) { moveLane(dx > 0 ? 1 : -1); t0.x = t.clientX; t0.y = t.clientY; }
  else if (dy < -34 && Math.abs(dy) > Math.abs(dx)) { jump(); t0.done = true; }
  e.preventDefault();
}, { passive: false });
canvas.addEventListener('touchend', e => { if (t0 && !t0.done && performance.now() - t0.t < 220 && state === 'play') { const t = e.changedTouches[0]; if (Math.abs(t.clientX - t0.x) < 12 && Math.abs(t.clientY - t0.y) < 12) jump(); } t0 = null; e.preventDefault(); }, { passive: false });
let mdown = null;
canvas.addEventListener('mousedown', e => { mdown = { x: e.clientX, y: e.clientY }; });
window.addEventListener('mouseup', e => { if (!mdown) return; const dx = e.clientX - mdown.x, dy = e.clientY - mdown.y; if (Math.abs(dx) > 30 && Math.abs(dx) > Math.abs(dy)) moveLane(dx > 0 ? 1 : -1); else if (dy < -30) jump(); mdown = null; });

function togglePause() { if (state === 'play') { setState('pause'); music.pause(); } else if (state === 'pause') { setState('play'); playMusic(); } }
$('btnPlay').onclick = () => startGame(Math.min(save.unlocked, NLEV) - 1);
$('btnNew').onclick = () => startGame(0);
$('btnLevels').onclick = () => { buildLevelGrid(); $('levels').classList.add('show'); };
$('btnLevelsBack').onclick = () => $('levels').classList.remove('show');
$('btnPause').onclick = togglePause; $('btnResume').onclick = togglePause;
$('btnHome').onclick = () => { setState('menu'); };
$('btnFinaleGo').onclick = () => { $('finale').classList.remove('show'); };
$('btnMute').onclick = () => { initAudio(); setMuted(!muted); }; $('btnMute2').onclick = $('btnMute').onclick;
function buildLevelGrid() {
  const g = $('lgrid'); g.innerHTML = '';
  for (let i = 0; i < NLEV; i++) {
    const b = document.createElement('button'), ok = i < save.unlocked; b.className = 'lv' + (ok ? '' : ' lock');
    b.innerHTML = '<b>' + (i + 1) + '</b><small>' + (ok ? LEVELS[i] : '🔒') + '</small>'; if (ok) b.onclick = () => startGame(i); g.appendChild(b);
  }
}
document.addEventListener('visibilitychange', () => { if (document.hidden) { if (state === 'play') togglePause(); else music.pause(); } });

/* ---------- pembaruan ---------- */
const bestEl = $('best');
function update(dt) {
  time += dt; R.time = time;
  if (state === 'play') {
    const target = 11 + L * 0.32; speed = lerp(speed, target, 1 - Math.exp(-dt * 1.4));
    pz -= speed * dt; lvDist += speed * dt; total += speed * dt;
    px = lerp(px, tx, 1 - Math.exp(-dt * 11)); lean = lerp(lean, clamp((tx - px) * 0.35, -0.45, 0.45), 1 - Math.exp(-dt * 8));
    vy -= 24 * dt; py += vy * dt; if (py < 0) { py = 0; vy = 0; }
    bump = Math.max(0, bump - dt); shake = Math.max(0, shake - dt * 2.2);
    const gap = Math.max(24, 46 - L * 0.75);
    while (nextSpawn > pz - 300) { spawnRow(nextSpawn); nextSpawn -= gap + rnd() * 8; }
    for (const o of obs) {
      o.z -= (o.v || 0) * dt;
      if (!o.hit && bump <= 0 && Math.abs(o.x - px) < o.hw + 0.35 && Math.abs(o.z - pz) < o.hd + 0.9 && py < o.h - 0.05) {
        o.hit = true; bump = 1.4; speed *= 0.55; shake = 1; sfx.bump(); if (navigator.vibrate) try { navigator.vibrate(40); } catch (e) {}
      }
    }
    for (const c of coins) if (!c.got && Math.abs(c.x - px) < 0.9 && Math.abs(c.z - pz) < 1.2 && Math.abs(c.y - (py + 0.9)) < 1.1) { c.got = true; coinsRun++; save.coins++; sfx.coin(); }
    obs = obs.filter(o => o.z < pz + 12); coins = coins.filter(c => !c.got && c.z < pz + 12);
    if (lvDist >= levelLen(L)) {
      lvDist -= levelLen(L); sfx.level();
      if (L < NLEV - 1) { L++; save.unlocked = Math.max(save.unlocked, L + 1); showToast('Level ' + (L + 1), LEVELS[L]); doSave(); }
      else if (!finished) { finished = true; $('finale').classList.add('show'); doSave(); }
    }
    save.best = Math.max(save.best, Math.floor(total));
    hud();
  } else if (state === 'menu') { pz -= 7 * dt; px = Math.sin(time * 0.3) * 1.2; lean = Math.cos(time * 0.3) * 0.08; py = 0; }
}
let hc = {};
function setT(id, v) { if (hc[id] !== v) { hc[id] = v; $(id).textContent = v; } }
function hud() {
  setT('hLevel', 'Level ' + (L + 1) + ' / ' + NLEV); setT('hName', LEVELS[L]); setT('hCoins', '🪙 ' + coinsRun); setT('hDist', Math.floor(total) + ' m');
  const p = Math.round(lvDist / levelLen(L) * 100); if (hc.p !== p) { hc.p = p; $('hBar').style.width = p + '%'; }
}

/* ---------- gambar ---------- */
const tmp = M4.ident(), vp = M4.ident();
const clouds = Array.from({ length: 12 }, (_, i) => ({ m: cloudM[i % 6], x: -320 + rnd() * 560, y: 75 + rnd() * 50, z: rnd() * 1400, s: 1.2 + rnd() * 1.6, sp: 0.4 + rnd() * 0.8 }));
const birds = Array.from({ length: 14 }, (_, i) => ({ cx: -30 - rnd() * 90, cz: -60 - i * 28, y: 14 + rnd() * 26, r: 14 + rnd() * 26, w: 0.25 + rnd() * 0.25, ph: rnd() * 6.28, fs: 6 + rnd() * 3 }));
const boats = [{ m: 0, x: -70, z: 100, v: -3.5 }, { m: 1, x: -42, z: -220, v: -5 }, { m: 0, x: -130, z: -480, v: 2.5 }, { m: 1, x: -95, z: -700, v: 6 }, { m: 1, x: -60, z: 300, v: -2 }];
const wrap = (z, c, period, back) => z - period * Math.floor((z - (c - back)) / period);
let lastLvTxt = '';

function render() {
  R.resize(1.6);
  const p = palette(((L + (state === 'play' ? lvDist / levelLen(L) : 0)) * 0.1 + 0.07) % 1);
  const night = clamp((0.28 - (p.top[0] + p.top[1] + p.top[2]) / 3) / 0.18, 0, 1);
  R.fog = p.bot.slice(); R.amb = p.amb; R.sunI = p.si;
  const sunDir = [0.55, p.el, -0.65], sl = Math.hypot(...sunDir); const sd = sunDir.map(v => v / sl);
  R.sun = [sd[0], Math.max(sd[1], 0.35), sd[2]]; { const l = Math.hypot(...R.sun); R.sun = R.sun.map(v => v / l); }
  const sh = shake * 0.12 * (Math.random() - 0.5);
  camX = lerp(camX, px, 0.1);
  const cam = [camX * 0.7 + sh, (R.aspect < 1 ? 5 : 4.3) + py * 0.3 + sh, pz + 8.8], look = [camX * 0.35, 1.7, pz - 13];
  if (state === 'menu') { cam[0] = -2.5 + Math.sin(time * 0.2) * 1.4; cam[1] = 3.4; cam[2] = pz + 8; look[0] = -2; look[1] = 3.2; look[2] = pz - 30; }
  const base = R.aspect < 1 ? 76 : 52, fov = (base + (state === 'play' ? (speed - 8) * 0.3 : 0)) * Math.PI / 180;
  const proj = M4.persp(fov, R.aspect, 0.5, 900);
  const view = M4.lookAt(cam, look, [0, 1, 0]); const VP = M4.mul(proj, view);
  R.begin(VP, cam);
  // langit, matahari/bulan, bintang
  M4.model(tmp, cam[0], cam[1], cam[2]); R.sky(skyM, tmp, p.top, p.bot);
  if (night > 0.05) { R.draw(starM, tmp, { unlit: true, alpha: night, tint: [1, 1, 1] }); }
  const sx = cam[0] + sd[0] * 250, sy = cam[1] + (night > 0.4 ? 0.6 : sd[1]) * 250, sz = cam[2] + sd[2] * 250;
  M4.model(tmp, sx, sy, sz, 0, 0, 0, night > 0.4 ? 0.7 : 1.3);
  if (sy > cam[1] - 20) R.draw(sunM, tmp, { unlit: true, tint: night > 0.4 ? [0.85, 0.9, 1] : [p.sc[0], p.sc[1] * 0.95, p.sc[2] * 0.8] });
  // awan
  for (const c of clouds) {
    const cz = wrap(c.z - time * c.sp * 0, pz, 1500, 900), cx = ((c.x + time * c.sp * 2 + 400) % 800) - 400 - 20;
    M4.model(tmp, cx, c.y, cz, 0, 0, 0, c.s); R.draw(c.m, tmp, { unlit: true, tint: [lerp(1, 0.25, night) * (0.8 + p.sc[0] * 0.2), lerp(1, 0.28, night) * (0.78 + p.sc[1] * 0.22), lerp(1, 0.4, night) * (0.7 + p.sc[2] * 0.3)] });
  }
  // sungai
  M4.model(tmp, 0, 0, Math.round(pz / 50) * 50); R.draw(waterM, tmp, { water: true });
  // tepian jauh
  const fi = Math.floor(-pz / 150);
  for (let i = fi - 1; i <= fi + 4; i++) { M4.model(tmp, 0, 0, -i * 150, 0, 0, 0, 1); R.draw(farV[((i % 3) + 3) % 3], tmp); }
  // jembatan (tiap 900 m)
  const bi = Math.floor(-pz / 900);
  for (let i = bi - 1; i <= bi + 1; i++) { const bz = -380 - i * 900; if (Math.abs(bz - pz) < 750) { M4.model(tmp, 0, 0, bz); R.draw(bridgeM, tmp); } }
  // jalan
  const ci = Math.floor(-pz / CHUNK_L);
  for (let i = ci - 1; i <= ci + 8; i++) {
    const v = roadV[((i * 7) % 4 + 4) % 4]; M4.model(tmp, 0, 0, -i * CHUNK_L); R.draw(v.m, tmp);
    if (night > 0.05) R.draw(v.g, tmp, { unlit: true, alpha: Math.min(0.8, night), tint: [1, 0.92, 0.7] });
  }
  // patung Pesut (tiap 420 m)
  const pi = Math.floor(-pz / 420);
  for (let i = pi - 1; i <= pi + 1; i++) { const zz = -260 - i * 420; M4.model(tmp, 10.5, 0, zz, Math.PI / 2, 0, 0, 1.3); R.draw(pesutM, tmp); }
  // perahu
  for (const b of boats) { const z = wrap(b.z + b.v * time, pz, 900, 560); M4.model(tmp, b.x, -4.4 + Math.sin(time + b.x) * 0.05, z, b.v > 0 ? 0 : Math.PI); R.draw(boatM[b.m], tmp); }
  // burung
  for (const b of birds) {
    const a = time * b.w + b.ph, dz = wrap(b.cz, pz, 500, 300);
    const x = b.cx + Math.cos(a) * b.r, z = dz + Math.sin(a) * b.r * 1.4 - 40, dxv = -Math.sin(a) * b.r * b.w, dzv = Math.cos(a) * b.r * 1.4 * b.w;
    M4.model(tmp, x, b.y + Math.sin(a * 2) * 1.5, z, Math.atan2(-dxv, -dzv), 0, -0.25, 1.1); R.draw(birdM[Math.floor(time * b.fs + b.ph) & 3], tmp);
  }
  // objek di jalan
  for (const o of obs) {
    if (o.z > pz + 14 || o.z < pz - 480) continue;
    if (o.t === 'car') { M4.model(tmp, o.x, 0, o.z, 0); R.draw(carM[o.k], tmp); }
    else if (o.t === 'bar') { M4.model(tmp, o.x, 0, o.z); R.draw(barrierM, tmp); }
    else { M4.model(tmp, o.x, 0, o.z); R.draw(coneM, tmp); }
  }
  for (const c of coins) { if (c.z < pz - 480) continue; M4.model(tmp, c.x, c.y + Math.sin(time * 3 + c.ph) * 0.1, c.z, time * 2.5 + c.ph, Math.PI / 2, 0, 1); R.draw(coinM, tmp); }
  // pemain
  const blink = bump > 0 && Math.floor(time * 14) % 2 === 0;
  M4.model(tmp, px, 0.03, pz, 0, 0, 0, 1); R.draw(shadowM, tmp, { unlit: true, alpha: 0.16 - py * 0.05, tint: [1, 1, 1] });
  if (!blink) { M4.model(tmp, px, py, pz, Math.PI, state === 'play' ? -0.02 - Math.min(0.08, vy * 0.006) : 0, -lean, 1); R.draw(playerM, tmp); }
}

/* ---------- loop ---------- */
let last = performance.now();
function loop(now) {
  const dt = Math.min((now - last) / 1000, 0.05); last = now;
  update(dt); render(); requestAnimationFrame(loop);
}
setMuted(muted); bestEl.textContent = save.best + ' m';
$('btnPlay').textContent = save.unlocked > 1 ? 'Lanjut Level ' + save.unlocked : 'Mulai Jalan-jalan';
window.__game = { get state() { return state; }, start: startGame, setLevel(n) { L = n; }, R };
requestAnimationFrame(loop);
})();
