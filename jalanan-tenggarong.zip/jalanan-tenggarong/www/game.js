/* Jalanan Tenggarong - game santai di tepi Sungai Mahakam */
'use strict';
(() => {
const $ = id => document.getElementById(id);
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const lerp = (a, b, t) => a + (b - a) * t;
const mix3 = (a, b, t) => [lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t)];

const LEVELS = ['Tepian Mahakam', 'Jembatan Kartanegara', 'Taman Pesut', 'Museum Mulawarman', 'Pulau Kumala', 'Keraton Sultan Kutai',
  'Pasar Tenggarong', 'Kampung Tepian Sungai', 'Dermaga Senja', 'Tugu Pesut', 'Kebun Kelapa Sawit Mini', 'Jalan Pahlawan',
  'Taman Kota Raja', 'Gerbang Kutai', 'Pelabuhan Tongkang', 'Bukit Biru', 'Rumah Panggung', 'Kedai Kopi Tepian',
  'Pelataran Lawang Gada', 'Danau Lipan', 'Sungai Belayan', 'Hutan Kota', 'Menara Pandang', 'Lembah Mahakam',
  'Desa Budaya', 'Sawah Hijau', 'Pelabuhan Lama', 'Tebing Hijau', 'Langit Kutai', 'Puncak Kartanegara'];
const NLEV = 30;
/* jarak tiap level: Level 1 = 1.000 m ... Level 30 = 7.000 m */
const levelLen = L => Math.round(1000 + L * (6000 / 29));

/* ---------- palet waktu (fajar → pagi → siang → sore → senja → malam) ---------- */
const KEYS = [
  { t: 0.00, top: [.42, .52, .78], bot: [.98, .74, .6], amb: [.52, .5, .62], el: .12, si: .55, sc: [1, .7, .5] },
  { t: 0.12, top: [.3, .6, .93], bot: [.86, .93, .98], amb: [.6, .62, .7], el: .45, si: .72, sc: [1, .95, .85] },
  { t: 0.35, top: [.17, .5, .95], bot: [.72, .87, .99], amb: [.66, .68, .74], el: .95, si: .8, sc: [1, 1, .95] },
  { t: 0.55, top: [.32, .5, .84], bot: [.99, .83, .6], amb: [.64, .58, .58], el: .33, si: .7, sc: [1, .8, .55] },
  { t: 0.68, top: [.22, .24, .55], bot: [1, .5, .3], amb: [.5, .42, .55], el: .07, si: .45, sc: [1, .55, .35] },
  { t: 0.80, top: [.03, .05, .17], bot: [.13, .16, .32], amb: [.34, .38, .58], el: .5, si: .22, sc: [.55, .65, 1] },
  { t: 0.92, top: [.1, .14, .33], bot: [.46, .4, .56], amb: [.4, .42, .56], el: .5, si: .25, sc: [.6, .62, .9] },
  { t: 1.00, top: [.42, .52, .78], bot: [.98, .74, .6], amb: [.52, .5, .62], el: .12, si: .55, sc: [1, .7, .5] }];
function palette(t) {
  let i = 0; while (i < KEYS.length - 2 && t > KEYS[i + 1].t) i++;
  const a = KEYS[i], b = KEYS[i + 1], k = clamp((t - a.t) / (b.t - a.t), 0, 1), s = k * k * (3 - 2 * k);
  return { top: mix3(a.top, b.top, s), bot: mix3(a.bot, b.bot, s), amb: mix3(a.amb, b.amb, s), el: lerp(a.el, b.el, s), si: lerp(a.si, b.si, s), sc: mix3(a.sc, b.sc, s) };
}

/* ---------- penyimpanan ---------- */
let save = { unlocked: 1, best: 0, coins: 0, owned: { helm: [0], baju: [0], jaket: [0], celana: [0], sepatu: [0], sayap: [0] }, equip: { helm: 0, baju: 0, jaket: 0, celana: 0, sepatu: 0, sayap: 0 } };
try { const s = JSON.parse(localStorage.getItem('jt_save') || 'null'); if (s) save = Object.assign(save, s); } catch (e) {}
for (const k of ['helm', 'baju', 'jaket', 'celana', 'sepatu', 'sayap']) {
  if (!save.owned || !Array.isArray(save.owned[k])) { save.owned = save.owned || {}; save.owned[k] = [0]; }
  if (!save.equip || typeof save.equip[k] !== 'number') { save.equip = save.equip || {}; save.equip[k] = 0; }
}
const doSave = () => { try { localStorage.setItem('jt_save', JSON.stringify(save)); } catch (e) {} };

/* ---------- renderer & aset ---------- */
const canvas = $('c'); let R;
try { R = new Renderer(canvas); } catch (e) { $('nogl').style.display = 'flex'; throw e; }
R.fogR = [130, 520];
const roadV = [1, 2, 3, 4].map(i => { const g = new MeshBuilder(), pt = new MeshBuilder(), mk = new MeshBuilder(), m = buildRoadChunk(i, g, pt, mk); return { m: R.upload(m), g: R.upload(g), p: R.upload(pt), k: R.upload(mk) }; });
const farV = [1, 2, 3].map(i => R.upload(buildFarBank(i)));
const waterM = R.upload(buildWater()), bridgeM = R.upload(buildBridge()), skyM = R.upload(buildSkyDome()), sunM = R.upload(buildSun()), starM = R.upload(buildStars());
const cloudM = [1, 2, 3, 4, 5, 6].map(i => R.upload(buildCloud(i)));
const birdM = [0, 1, 2, 3].map(i => R.upload(buildBird(i)));
const pesutM = R.upload(buildPesut()), gateM = R.upload(buildGate());
let runnerM = null;
function rebuildRunner() { if (runnerM) for (const k in runnerM) R.free(runnerM[k]); const b = buildRunner(save.equip); runnerM = {}; for (const k in b) runnerM[k] = R.upload(b[k]); }
rebuildRunner();
const carM = [0, 1, 2, 3, 4].map(i => R.upload(buildCar(i))), barrierM = R.upload(buildBarrier()), coneM = R.upload(buildCone()), coinM = R.upload(buildCoin());
const boatM = [R.upload(buildBoat(0)), R.upload(buildBoat(1))];
const shadowM = (() => { const m = new MeshBuilder(); for (let i = 0; i < 10; i++) { const a = i / 10 * 6.2832, b = (i + 1) / 10 * 6.2832; m.tri([0, .03, 0], [Math.cos(b) * .55, .03, Math.sin(b) * 1.15], [Math.cos(a) * .55, .03, Math.sin(a) * 1.15], [0, 0, 0], [0, 1, 0]); } return R.upload(m); })();

/* ---------- audio ---------- */
const music = $('music'); let actx = null, muted = false, noiseBuf = null, duckT = 0;
const TRACKS = [
  { src: 'assets/aku-menyanyi.mp3', title: 'Aku Menyanyi' },
  { src: 'assets/nasib-awak.mp3', title: 'Nasib Awak (Jajak Penyek)' },
  { src: 'assets/begenjoh.mp3', title: 'Begenjoh' },
  { src: 'assets/music.mp3', title: 'Musik Jalanan Tenggarong' }];
let trackI = 0;
try { const s = localStorage.getItem('jt_muted'); muted = s === '1'; const t = parseInt(localStorage.getItem('jt_track'), 10); if (t >= 0 && t < TRACKS.length) trackI = t; } catch (e) {}
function initAudio() { if (!actx) { try { actx = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) {} } if (actx && actx.state === 'suspended') actx.resume(); }
function loadTrack(i, announce) {
  trackI = (i + TRACKS.length) % TRACKS.length; music.src = TRACKS[trackI].src; music.load();
  try { localStorage.setItem('jt_track', String(trackI)); } catch (e) {}
  $('trackName').textContent = '♪ ' + TRACKS[trackI].title;
  if (announce) { const n = $('np'); n.textContent = '♪ ' + TRACKS[trackI].title; n.classList.remove('go'); void n.offsetWidth; n.classList.add('go'); }
}
function playMusic() { if (!music.getAttribute('src')) loadTrack(trackI, false); music.volume = duckT > 0 ? 0.18 : 0.8; music.muted = muted; const p = music.play(); if (p && p.catch) p.catch(() => {}); }
function nextTrack() { loadTrack(trackI + 1, true); if (state !== 'pause') playMusic(); }
music.addEventListener('ended', () => { loadTrack(trackI + 1, true); playMusic(); });
music.addEventListener('error', () => { if (music.getAttribute('src')) setTimeout(() => { loadTrack(trackI + 1, false); playMusic(); }, 400); });
function tone(f0, f1, dur, type, vol, delay) {
  if (!actx || muted) return; const t = actx.currentTime + (delay || 0), o = actx.createOscillator(), g = actx.createGain();
  o.type = type || 'sine'; o.frequency.setValueAtTime(f0, t); o.frequency.exponentialRampToValueAtTime(Math.max(f1, 1), t + dur);
  g.gain.setValueAtTime(vol || 0.15, t); g.gain.exponentialRampToValueAtTime(0.001, t + dur); o.connect(g); g.connect(actx.destination); o.start(t); o.stop(t + dur + 0.02);
}
/* nada panjang dengan filter (terompet / xilofon) */
function note(f, t0, dur, type, vol, cutoff) {
  const t = actx.currentTime + t0, o = actx.createOscillator(), g = actx.createGain(), fl = actx.createBiquadFilter();
  o.type = type; o.frequency.setValueAtTime(f, t); fl.type = 'lowpass'; fl.frequency.setValueAtTime(cutoff || 2400, t);
  if (type === 'sawtooth' || type === 'square') { fl.frequency.setValueAtTime(cutoff * 0.5, t); fl.frequency.linearRampToValueAtTime(cutoff, t + 0.06); const lf = actx.createOscillator(), lg = actx.createGain(); lf.frequency.value = 5.5; lg.gain.value = f * 0.006; lf.connect(lg); lg.connect(o.frequency); lf.start(t + 0.12); lf.stop(t + dur + 0.05); }
  g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol, t + 0.02); g.gain.setValueAtTime(vol, t + Math.max(0.03, dur - 0.08)); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  o.connect(fl); fl.connect(g); g.connect(actx.destination); o.start(t); o.stop(t + dur + 0.05);
}
function noiseHit(t0, dur, vol, hp, lp) {
  if (!noiseBuf) { noiseBuf = actx.createBuffer(1, actx.sampleRate, actx.sampleRate); const d = noiseBuf.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1; }
  const t = actx.currentTime + t0, s = actx.createBufferSource(), g = actx.createGain(), h = actx.createBiquadFilter(), l = actx.createBiquadFilter();
  s.buffer = noiseBuf; h.type = 'highpass'; h.frequency.value = hp; l.type = 'lowpass'; l.frequency.value = lp;
  g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.001, t + dur); s.connect(h); h.connect(l); l.connect(g); g.connect(actx.destination); s.start(t); s.stop(t + dur + 0.02);
}
/* instrumen perayaan: fanfare terompet + drum + rebana + xilofon (~5 detik) */
function celebrateSound() {
  if (!actx || muted) return; if (actx.state === 'suspended') actx.resume();
  const mel = [[392, 0, .13], [392, .16, .13], [392, .32, .13], [523.25, .5, .5], [440, 1.05, .2], [523.25, 1.27, .2], [659.25, 1.5, .75], [587.33, 2.35, .2], [659.25, 2.58, .2], [784, 2.82, 1.1]];
  for (const [f, t, d] of mel) { note(f, t, d, 'sawtooth', 0.11, 2600); note(f / 2, t, d, 'square', 0.04, 900); }
  for (const f of [523.25, 659.25, 784, 1046.5]) note(f, 3.9, 1.2, 'sawtooth', 0.07, 2400);
  for (let i = 0; i < 12; i++) noiseHit(i * 0.04, 0.06, 0.09, 1200, 6000); // gulungan snare
  for (let i = 0; i < 8; i++) noiseHit(2.25 + i * 0.07, 0.06, 0.09, 1200, 6000);
  for (const t of [0.5, 1.0, 1.5, 2.0, 2.82, 3.9]) { tone(150, 45, 0.25, 'sine', 0.5, t); noiseHit(t, 0.08, 0.1, 2000, 5000); }
  for (let t = 0.25; t < 4.8; t += 0.25) noiseHit(t, 0.07, 0.07, 6000, 12000); // rebana / shaker
  const xy = [1046.5, 1318.5, 1568, 2093, 1568, 1318.5, 1046.5, 1318.5, 1568, 2093, 2637, 3136];
  xy.forEach((f, i) => note(f, 3.9 + i * 0.1, 0.35, 'triangle', 0.09, 6000));
  duckT = 5.6; music.volume = 0.18; clearTimeout(celebrateSound.t); celebrateSound.t = setTimeout(() => { duckT = 0; if (state !== 'pause') music.volume = 0.8; }, 5600);
}
const sfx = {
  coin() { tone(988, 988, 0.08, 'sine', 0.13); tone(1319, 1319, 0.16, 'sine', 0.13, 0.07); },
  bump() { // suara tabrakan: benturan, dentang logam, dan gedebuk
    if (!actx || muted) return;
    noiseHit(0, 0.4, 0.55, 80, 2200); noiseHit(0.01, 0.16, 0.32, 2500, 9000);
    tone(95, 28, 0.45, 'sine', 0.7); tone(170, 45, 0.35, 'sawtooth', 0.28);
    tone(540, 250, 0.28, 'square', 0.12); tone(810, 380, 0.22, 'square', 0.08, 0.03); tone(330, 140, 0.4, 'triangle', 0.16, 0.08);
  },
  jump() { tone(380, 720, 0.14, 'sine', 0.12); },
  buy() { [659, 880, 1175].forEach((f, i) => tone(f, f, 0.2, 'triangle', 0.14, i * 0.08)); },
  no() { tone(220, 160, 0.25, 'square', 0.1); },
  over() { [392, 330, 262, 196].forEach((f, i) => tone(f, f * 0.98, 0.3, 'triangle', 0.18, 0.6 + i * 0.18)); }
};
function setMuted(m) { muted = m; music.muted = m; $('btnMute').textContent = m ? '🔇' : '🔊'; $('btnMute2').textContent = m ? '🔇 Musik mati' : '🔊 Musik'; try { localStorage.setItem('jt_muted', m ? '1' : '0'); } catch (e) {} }

/* ---------- status game ---------- */
let state = 'menu', L = 0, lvDist = 0, total = 0, coinsRun = 0, time = 0, hp = 3, inv = 0, blinkOn = false;
let pz = 0, px = 0, py = 0, vy = 0, speed = 8, lane = 1, tx = 0, bump = 0, shake = 0, lean = 0, camX = 0, ph = 0, air = 0, cheer = 0, shopTab = 'helm', autoT = 0, pvx = 0, yaw = 0, landK = 0, landS = 0, jumpBuf = 0;
let obs = [], coins = [], nextSpawn = -60, gates = [];
const rnd = Math.random;
const MAXHP = 3;
/* kecepatan lari tiap level: Level 1 = 70 km/j ... Level 30 = 500 km/j (naik rata) */
const speedFor = l => (70 + l * (430 / 29)) / 3.6;
const SPAWN_AHEAD = 560;

function beginLevel(level, keepTotal) {
  initAudio(); playMusic();
  L = clamp(level, 0, NLEV - 1); lvDist = 0; if (!keepTotal) total = 0; coinsRun = 0; px = LANES[1]; tx = LANES[1]; lane = 1; py = 0; vy = 0; pvx = 0; yaw = 0; landK = 0; landS = 0; jumpBuf = 0; speed = 0; bump = 0; shake = 0; hp = MAXHP;
  inv = 1.6; blinkOn = false; obs = []; coins = []; gates = gates.filter(z => z < pz + 40); nextSpawn = pz - 70; clearTimeout(autoT);
  setState('play'); showToast('Level ' + (L + 1), LEVELS[L] + ' · ' + Math.round(speedFor(L) * 3.6) + ' km/j'); hud(true);
}
const startGame = level => beginLevel(level, false);
function setState(s) {
  state = s; $('menu').classList.toggle('show', s === 'menu'); $('levels').classList.remove('show'); $('pause').classList.toggle('show', s === 'pause');
  $('hud').classList.toggle('show', s === 'play' || s === 'pause'); $('celebrate').classList.toggle('show', s === 'celebrate'); $('dead').classList.toggle('show', s === 'dead'); $('shop').classList.toggle('show', s === 'shop');
}
function showToast(a, b) { const t = $('toast'); t.innerHTML = '<b>' + a + '</b><span>' + b + '</span>'; t.classList.remove('go'); void t.offsetWidth; t.classList.add('go'); }

/* ---------- spawn ---------- */
function addCar(lanei, z) { const k = (rnd() * 5) | 0; obs.push({ t: 'car', k, x: LANES[lanei], z, hw: 1.05, hd: k === 4 ? 2.8 : 2.1, h: 1.9, v: 2 + rnd() * 3 }); }
function addBarrier(lanei, z) { obs.push({ t: 'bar', x: LANES[lanei], z, hw: 1.05, hd: 0.3, h: 1.0, v: 0 }); }
function addCones(lanei, z) { for (let i = 0; i < 3; i++) obs.push({ t: 'cone', x: LANES[lanei] + (i - 1) * 0.5, z: z - i * 0.6, hw: 0.38, hd: 0.38, h: 0.9, v: 0 }); }
function addCoins(lanei, z, n, arc) { for (let i = 0; i < n; i++) coins.push({ x: LANES[lanei], z: z - i * 2.3, y: arc ? 1.1 + Math.sin(i / (n - 1) * Math.PI) * 1.2 : 1.1, got: false, ph: rnd() * 6 }); }
function spawnRow(z) {
  const free = [0, 1, 2].sort(() => rnd() - 0.5), r = rnd(), easy = L < 2 ? 0.25 : 0;
  if (r < 0.22 + easy) addCoins(free[0], z, 8, false);
  else if (r < 0.45) { addCar(free[0], z); addCoins(free[1], z + 4, 7, false); }
  else if (r < 0.58 + (L > 4 ? 0.07 : 0)) { addCar(free[0], z); addCar(free[1], z - 4); addCoins(free[2], z + 3, 8, false); }
  else if (r < 0.78) { addBarrier(free[0], z); if (L > 3 && rnd() < 0.5) addBarrier(free[1], z); addCoins(free[0], z + 5, 5, true); }
  else if (r < 0.9) { addCones(free[0], z); addCoins(free[1], z + 3, 6, false); }
  else { addBarrier(free[0], z); addCoins(free[2], z, 9, false); }
}

/* ---------- input ---------- */
function moveLane(d) { if (state !== 'play') return; lane = clamp(lane + d, 0, 2); tx = LANES[lane]; }
function jump() { if (state !== 'play') return; if (py <= 0.01) { vy = 9.1; landK = 0; sfx.jump(); } else jumpBuf = 0.14; }
window.addEventListener('keydown', e => {
  const k = e.key;
  if (k === 'ArrowLeft' || k === 'a' || k === 'A') moveLane(-1); else if (k === 'ArrowRight' || k === 'd' || k === 'D') moveLane(1);
  else if (k === 'ArrowUp' || k === 'w' || k === 'W' || k === ' ') jump(); else if (k === 'p' || k === 'Escape') togglePause();
});
let t0 = null;
canvas.addEventListener('touchstart', e => { const t = e.changedTouches[0]; t0 = { x: t.clientX, y: t.clientY, t: performance.now(), done: false }; e.preventDefault(); }, { passive: false });
canvas.addEventListener('touchmove', e => {
  if (!t0 || t0.done) return; const t = e.changedTouches[0], dx = t.clientX - t0.x, dy = t.clientY - t0.y;
  if (Math.abs(dx) > 28 && Math.abs(dx) > Math.abs(dy)) { moveLane(dx > 0 ? 1 : -1); t0.x = t.clientX; t0.y = t.clientY; }
  else if (dy < -34 && Math.abs(dy) > Math.abs(dx)) { jump(); t0.done = true; }
  e.preventDefault();
}, { passive: false });
canvas.addEventListener('touchend', e => { if (t0 && !t0.done && performance.now() - t0.t < 220 && state === 'play') { const t = e.changedTouches[0]; if (Math.abs(t.clientX - t0.x) < 12 && Math.abs(t.clientY - t0.y) < 12) jump(); } t0 = null; e.preventDefault(); }, { passive: false });
let mdown = null;
canvas.addEventListener('mousedown', e => { mdown = { x: e.clientX, y: e.clientY }; });
window.addEventListener('mouseup', e => { if (!mdown) return; const dx = e.clientX - mdown.x, dy = e.clientY - mdown.y; if (Math.abs(dx) > 30 && Math.abs(dx) > Math.abs(dy)) moveLane(dx > 0 ? 1 : -1); else if (dy < -30) jump(); mdown = null; });

function togglePause() { if (state === 'play') { setState('pause'); music.pause(); } else if (state === 'pause') { setState('play'); playMusic(); } }
$('btnPlay').onclick = () => startGame(Math.min(save.unlocked, NLEV) - 1);
$('btnNew').onclick = () => startGame(0);
$('btnLevels').onclick = () => { buildLevelGrid(); $('levels').classList.add('show'); };
$('btnLevelsBack').onclick = () => $('levels').classList.remove('show');
$('btnPause').onclick = togglePause; $('btnResume').onclick = togglePause;
$('btnHome').onclick = () => { setState('menu'); updateMenu(); };
$('btnHome2').onclick = () => { setState('menu'); updateMenu(); };
$('btnMute').onclick = () => { initAudio(); setMuted(!muted); }; $('btnMute2').onclick = $('btnMute').onclick;
$('btnNext').onclick = () => { initAudio(); nextTrack(); }; $('btnNext2').onclick = $('btnNext').onclick;
$('btnRetry').onclick = () => beginLevel(L, true);
$('btnCont').onclick = () => nextLevel();
$('btnShop').onclick = () => { initAudio(); openShop(); }; $('btnShopClose').onclick = () => { setState('menu'); updateMenu(); };
function buildLevelGrid() {
  const g = $('lgrid'); g.innerHTML = '';
  for (let i = 0; i < NLEV; i++) {
    const b = document.createElement('button'), ok = i < save.unlocked; b.className = 'lv' + (ok ? '' : ' lock');
    b.innerHTML = '<b>' + (i + 1) + '</b><small>' + (ok ? LEVELS[i] + '<br>' + Math.round(speedFor(i) * 3.6) + ' km/j · ' + levelLen(i) + ' m' : '🔒') + '</small>'; if (ok) b.onclick = () => startGame(i); g.appendChild(b);
  }
}
document.addEventListener('visibilitychange', () => { if (document.hidden) { if (state === 'play') togglePause(); else music.pause(); } });

/* ---------- toko kosmetik ---------- */
const SLOTS = [['helm', 'Helm'], ['baju', 'Baju'], ['jaket', 'Jaket'], ['celana', 'Celana'], ['sepatu', 'Sepatu'], ['sayap', 'Sayap']];
const css = c => 'rgb(' + c.map(v => Math.round(v * 255)).join(',') + ')';
const coinHTML = '<i class="cn"></i>';

/* ikon mini item toko (SVG) */
function itemIcon(slot, i, it) {
  const c = css(it.c), c2 = it.c2 ? css(it.c2) : null, dk = 'rgba(0,0,0,.35)', st = ' stroke="' + dk + '" stroke-width="1.5" stroke-linejoin="round"';
  const gold = '#ffd34d', P = (d, f, x) => '<path d="' + d + '" fill="' + f + '"' + st + (x || '') + '/>';
  let s = '';
  if (slot === 'helm') {
    if (i === 0) s = P('M12 40 Q12 18 32 18 Q52 18 52 40 Q52 30 32 28 Q12 30 12 40Z', '#2a211c') + '<circle cx="32" cy="42" r="10" fill="#dba075"' + st + '/>' + '<text x="32" y="58" font-size="9" text-anchor="middle" fill="#fff" opacity=".6">—</text>';
    else if (i === 1) s = P('M13 40 Q13 16 34 16 Q50 16 51 40Z', c) + P('M40 40 L62 42 L62 46 L40 46Z', c) + '<circle cx="32" cy="14" r="3" fill="#fff"/>';
    else if (i === 2) s = P('M14 42 Q14 14 32 14 Q50 14 50 42Z', c) + P('M8 42 L56 42 L56 48 L8 48Z', c) + '<rect x="29" y="14" width="6" height="28" fill="#e6a60d"/>';
    else if (i === 3) s = P('M14 46 Q14 36 32 36 Q50 36 50 46Z', '#8b1519') + P('M20 38 Q22 20 32 16 Q44 22 44 38Z', '#c0262a') + P('M16 44 L48 44 L48 48 L16 48Z', gold) + P('M30 16 Q38 4 46 12 Q40 14 36 20Z', '#d9332f');
    else s = P('M12 46 L12 24 L22 34 L32 16 L42 34 L52 24 L52 46Z', c) + '<rect x="12" y="42" width="40" height="6" fill="#e0a21f"/>' + '<circle cx="32" cy="36" r="3.5" fill="#e5232f"/><circle cx="20" cy="38" r="2" fill="#fff"/><circle cx="44" cy="38" r="2" fill="#fff"/>';
  } else if (slot === 'baju' || slot === 'jaket') {
    const long = it.long, sl = long ? 52 : 34, jk = slot === 'jaket';
    if (jk && i === 0) { s = '<text x="32" y="40" font-size="26" text-anchor="middle" fill="#fff" opacity=".55">✕</text>'; }
    else {
      s = P('M22 12 L10 18 L' + (long ? 4 : 6) + ' ' + sl + ' L16 ' + (sl + 2) + ' L19 30 L19 54 L45 54 L45 30 L48 ' + (sl + 2) + ' L' + (long ? 60 : 58) + ' ' + sl + ' L54 18 L42 12 Q32 20 22 12Z', c);
      if (jk) { s += '<rect x="30.5" y="18" width="3" height="36" fill="' + c2 + '"/><rect x="19" y="50" width="26" height="4" fill="' + c2 + '"/>'; if (it.hood) s += P('M22 12 Q32 2 42 12 Q32 24 22 12Z', c2 ? c : c); if (it.collar) s += P('M22 12 L30 22 L26 24Z', c2) + P('M42 12 L34 22 L38 24Z', c2); }
      else if (i === 2) s += '<rect x="19" y="30" width="26" height="5" fill="#fff"/><rect x="19" y="40" width="26" height="5" fill="#fff"/>';
      else if (i === 3) s += '<rect x="19" y="26" width="26" height="3" fill="' + c2 + '"/><rect x="19" y="34" width="26" height="3" fill="' + c2 + '"/><rect x="19" y="42" width="26" height="3" fill="' + c2 + '"/><rect x="19" y="50" width="26" height="3" fill="' + c2 + '"/>';
      else if (i === 4) s += '<rect x="30" y="14" width="4" height="40" fill="' + c2 + '"/><rect x="19" y="46" width="26" height="4" fill="' + c2 + '"/>';
      else s += '<path d="M26 12 Q32 20 38 12" fill="none" stroke="' + dk + '" stroke-width="2"/>';
    }
  } else if (slot === 'celana') {
    const sh = it.short, ly = sh ? 36 : 56;
    s = P('M18 10 L46 10 L48 ' + ly + ' L35 ' + ly + ' L32 24 L29 ' + ly + ' L16 ' + ly + 'Z', c) + '<rect x="18" y="10" width="28" height="5" fill="rgba(0,0,0,.22)"/>';
    if (sh) s += '<rect x="17" y="40" width="13" height="14" fill="#dba075"/><rect x="34" y="40" width="13" height="14" fill="#dba075"/><rect x="17" y="48" width="13" height="4" fill="#fff"/><rect x="34" y="48" width="13" height="4" fill="#fff"/>';
  } else if (slot === 'sepatu') {
    s = P('M10 20 L28 20 L28 36 Q44 36 54 44 Q58 50 54 52 L10 52Z', c) + '<rect x="10" y="48" width="46" height="6" rx="2" fill="#f2f2f2"' + st + '/>' + '<path d="M28 28 L36 28 M28 33 L38 33" stroke="rgba(255,255,255,.7)" stroke-width="2"/>' + '<rect x="10" y="20" width="18" height="6" fill="rgba(0,0,0,.2)"/>';
  } else {
    if (i === 0) s = '<text x="32" y="42" font-size="26" text-anchor="middle" fill="#fff" opacity=".55">✕</text>';
    else {
      const f1 = c, f2 = c2 || c, W = (m) => {
        let r = '';
        if (i === 2) { r = P('M30 30 Q14 8 4 14 Q10 22 8 30 Q14 28 16 36 Q22 32 26 40 Q28 36 30 40Z', f1); r += '<path d="M30 30 L8 16 M30 32 L12 32 M30 36 L18 38" stroke="' + f2 + '" stroke-width="2" fill="none"/>'; }
        else if (i === 3) { r = P('M30 28 L6 10 L12 24 L4 28 L14 34 L8 42 L22 40 L30 44Z', f1); r += P('M30 32 L12 26 L16 34 L10 38Z', f2); }
        else { r = P('M30 28 Q18 6 4 10 Q6 20 4 26 Q10 28 10 34 Q16 32 18 40 Q26 38 30 44Z', f1); r += P('M30 32 Q20 20 10 22 Q12 28 12 32Z', f2); }
        return r;
      };
      s = '<g>' + W() + '</g><g transform="translate(64 0) scale(-1 1)">' + W() + '</g>';
    }
  }
  return '<svg class="ic" viewBox="0 0 64 64" width="52" height="52">' + s + '</svg>';
}
function openShop() { setState('shop'); renderShop(); }
function renderShop() {
  $('shopCoins').innerHTML = coinHTML + ' ' + save.coins;
  const tabs = $('shopTabs'); tabs.innerHTML = '';
  for (const [k, n] of SLOTS) { const b = document.createElement('button'); b.className = 'tab' + (k === shopTab ? ' on' : ''); b.textContent = n; b.onclick = () => { shopTab = k; renderShop(); }; tabs.appendChild(b); }
  const grid = $('shopGrid'); grid.innerHTML = '';
  SHOP[shopTab].forEach((it, i) => {
    const owned = save.owned[shopTab].indexOf(i) >= 0, on = save.equip[shopTab] === i, d = document.createElement('div'); d.className = 'item' + (on ? ' on' : '');
    const sw = '<span class="sw">' + itemIcon(shopTab, i, it) + '</span>';
    let btn;
    if (on) btn = '<button class="buy eq" disabled>Dipakai ✓</button>';
    else if (owned) btn = '<button class="buy use">Pakai</button>';
    else btn = '<button class="buy' + (save.coins >= it.p ? '' : ' poor') + '">' + coinHTML + ' ' + it.p + '</button>';
    d.innerHTML = sw + '<b>' + it.n + '</b>' + btn;
    const bt = d.querySelector('button'); if (!on) bt.onclick = () => buyOrEquip(shopTab, i);
    grid.appendChild(d);
  });
}
function buyOrEquip(slot, i) {
  const it = SHOP[slot][i];
  if (save.owned[slot].indexOf(i) < 0) {
    if (save.coins < it.p) { sfx.no(); const w = $('shopCoins'); w.classList.remove('shake'); void w.offsetWidth; w.classList.add('shake'); showToast('Koin kurang', 'Butuh ' + (it.p - save.coins) + ' koin lagi'); return; }
    save.coins -= it.p; save.owned[slot].push(i);
  }
  save.equip[slot] = i; sfx.buy(); doSave(); rebuildRunner(); renderShop();
}

/* ---------- hati, selesai level, kalah ---------- */
function heartsHTML() { let h = ''; for (let i = 0; i < MAXHP; i++) h += '<span class="' + (i < hp ? 'on' : 'off') + '">♥</span>'; return h; }
function loseHeart() {
  hp--; inv = 1.6; blinkOn = true; bump = 1; speed *= 0.6; shake = 1; sfx.bump(); if (navigator.vibrate) try { navigator.vibrate(60); } catch (e) {}
  const f = $('flash'); f.classList.remove('go'); void f.offsetWidth; f.classList.add('go');
  const hh = $('hHearts'); hh.classList.remove('hit'); void hh.offsetWidth; hh.classList.add('hit'); hud(true);
  if (hp <= 0) die();
}
function die() {
  state = 'dead'; sfx.over(); music.volume = 0.3;
  $('deadTxt').textContent = 'Hati habis! Kamu mengulang dari Level ' + (L + 1) + ' (' + LEVELS[L] + ').'; $('btnRetry').textContent = 'Ulangi Level ' + (L + 1);
  setTimeout(() => { if (state === 'dead') setState('dead'); }, 700); // overlay tampil setelah jeda singkat agar tabrakan terlihat
  $('hud').classList.remove('show');
}
function completeLevel() {
  gates.push(pz + Math.max(0, lvDist - levelLen(L))); state = 'celebrate'; const bonus = 20 + L * 5, last = L >= NLEV - 1; save.coins += bonus;
  save.unlocked = Math.max(save.unlocked, Math.min(NLEV, L + 2)); doSave();
  $('cTitle').textContent = last ? 'SEMUA LEVEL TAMAT!' : 'LEVEL ' + (L + 1) + ' SELESAI!';
  $('cBonus').innerHTML = '+' + bonus + ' ' + coinHTML + ' bonus koin';
  $('btnCont').textContent = last ? 'Main Lagi Level 30' : 'Lanjut ke Level ' + (L + 2);
  const cf = $('confetti'); if (!cf.children.length) for (let i = 0; i < 46; i++) { const p = document.createElement('i'); p.style.left = (rnd() * 100) + '%'; p.style.background = ['#ffd25a', '#ff5a5f', '#4cc9f0', '#7bd88f', '#fff', '#c77dff'][i % 6]; p.style.animationDelay = (rnd() * 2.5) + 's'; p.style.animationDuration = (2.2 + rnd() * 2) + 's'; p.style.transform = 'rotate(' + (rnd() * 360) + 'deg)'; cf.appendChild(p); }
  const c = $('celebrate'); c.classList.remove('replay'); void c.offsetWidth; c.classList.add('replay');
  setState('celebrate'); celebrateSound();
  clearTimeout(autoT); autoT = setTimeout(() => { if (state === 'celebrate') nextLevel(); }, 8500);
}
function nextLevel() {
  clearTimeout(autoT); if (state !== 'celebrate') return;
  if (L < NLEV - 1) L++; lvDist = 0; coinsRun = 0; obs = obs.filter(o => o.z < pz - 70); inv = 1.4; blinkOn = false; hp = Math.max(hp, 1);
  setState('play'); playMusic(); showToast('Level ' + (L + 1), LEVELS[L] + ' · ' + Math.round(speedFor(L) * 3.6) + ' km/j'); hud(true);
}

/* pegas teredam kritis: gerak belok mulus (mulai pelan, cepat di tengah, berhenti halus) */
function smoothDamp(cur, target, vel, st, dt) {
  const om = 2 / st, x = om * dt, e = 1 / (1 + x + 0.48 * x * x + 0.235 * x * x * x), ch = cur - target, t = (vel + om * ch) * dt;
  return [target + (ch + t) * e, (vel - om * t) * e];
}
/* ---------- pembaruan ---------- */
const bestEl = $('best');
function update(dt) {
  time += dt; R.time = time;
  if (duckT > 0) duckT -= dt;
  const run = state === 'play' || state === 'celebrate' || state === 'dead';
  if (state === 'play') {
    const target = speedFor(L); speed = lerp(speed, target, 1 - Math.exp(-dt * (speed < target * 0.6 ? 2.4 : 1.4)));
    const prevPz = pz; pz -= speed * dt; lvDist += speed * dt; total += speed * dt;
    { const r = smoothDamp(px, tx, pvx, 0.11, dt); px = r[0]; pvx = r[1]; }
    { const k = 1 - Math.exp(-dt * 12); lean = lerp(lean, clamp(pvx * 0.035, -0.4, 0.4), k); yaw = lerp(yaw, clamp(-pvx * 0.03, -0.38, 0.38), k); }
    vy -= (vy > 0 ? 24 : 36) * dt; const ny = py + vy * dt;
    if (ny <= 0) { if (vy < -3) landK = clamp(-vy / 11, 0.3, 1); py = 0; vy = 0; if (jumpBuf > 0) { jumpBuf = 0; vy = 9.1; landK = 0; sfx.jump(); } } else py = ny;
    jumpBuf = Math.max(0, jumpBuf - dt);
    bump = Math.max(0, bump - dt); shake = Math.max(0, shake - dt * 2.2); inv = Math.max(0, inv - dt); if (inv <= 0) blinkOn = false;
    const gap = 30 + target * 1.25;
    const gz = pz - (levelLen(L) - lvDist); // posisi gapura finis level ini
    while (nextSpawn > pz - SPAWN_AHEAD) { if (Math.abs(nextSpawn - gz) > 24) spawnRow(nextSpawn); nextSpawn -= gap + rnd() * 8; }
    for (const o of obs) {
      o.z -= (o.v || 0) * dt;
      if (!o.hit && inv <= 0 && Math.abs(o.x - px) < o.hw + 0.3 && o.z + o.hd + 0.8 >= pz && o.z - o.hd - 0.8 <= prevPz && py < o.h - 0.05) { o.hit = true; loseHeart(); if (state !== 'play') break; }
    }
    if (state === 'play') {
      for (const c of coins) if (!c.got && Math.abs(c.x - px) < 1.0 && c.z + 1.3 >= pz && c.z - 1.3 <= prevPz && Math.abs(c.y - (py + 1.0)) < 1.2) { c.got = true; coinsRun++; save.coins++; sfx.coin(); popCoin(); }
      obs = obs.filter(o => o.z < pz + 12); coins = coins.filter(c => !c.got && c.z < pz + 12);
      if (lvDist >= levelLen(L)) completeLevel();
      save.best = Math.max(save.best, Math.floor(total));
      hud();
    }
  } else if (state === 'celebrate' || state === 'dead') {
    speed = lerp(speed, 0, 1 - Math.exp(-dt * 3)); pz -= speed * dt; px = lerp(px, tx, 1 - Math.exp(-dt * 8)); lean = lerp(lean, 0, 1 - Math.exp(-dt * 6)); yaw = lerp(yaw, 0, 1 - Math.exp(-dt * 8)); pvx = 0;
    bump = Math.max(0, bump - dt); shake = Math.max(0, shake - dt * 2.2);
    if (state === 'celebrate') { const hop = Math.abs(Math.sin(time * 6)) * 0.28; py = hop; } else { py = 0; }
  } else if (state === 'menu') { pz -= 7 * dt; px = Math.sin(time * 0.3) * 1.2; lean = Math.cos(time * 0.3) * 0.08; py = 0; speed = 8; }
  else if (state === 'shop') { pz -= 2.5 * dt; px = 0; py = 0; lean = 0; speed = 5; }
  /* animasi lari */
  const runSpeed = state === 'celebrate' || state === 'dead' ? speed : (state === 'pause' ? 0 : speed);
  if (state !== 'pause' && state !== 'dead') ph += dt * (state === 'celebrate' ? 5 : Math.min(22, 6.5 + runSpeed * 0.5));
  { const ta = (state === 'play' && py > 0.08) ? 1 : 0; air = lerp(air, ta, 1 - Math.exp(-dt * (ta > air ? 24 : 13))); }
  landK = Math.max(0, landK - dt * 3.4); landS = lerp(landS, landK, 1 - Math.exp(-dt * 26));
  cheer = lerp(cheer, state === 'celebrate' ? 1 : 0, 1 - Math.exp(-dt * 8));
}
let hc = {};
function setT(id, v) { if (hc[id] !== v) { hc[id] = v; $(id).textContent = v; } }
function setH(id, v) { if (hc[id] !== v) { hc[id] = v; $(id).innerHTML = v; } }
function popCoin() { const e = $('hCoins'); e.classList.remove('pop'); void e.offsetWidth; e.classList.add('pop'); }
function hud(force) {
  if (force) hc = {};
  setT('hLevel', 'Level ' + (L + 1) + ' / ' + NLEV); setT('hName', LEVELS[L]); setH('hHearts', heartsHTML()); setH('hCoins', coinHTML + ' ' + save.coins);
  setT('hDist', Math.floor(total) + ' m · ' + Math.round(speed * 3.6) + ' km/j');
  const p = Math.round(lvDist / levelLen(L) * 100); if (hc.p !== p) { hc.p = p; $('hBar').style.width = p + '%'; }
}
function updateMenu() { bestEl.textContent = save.best + ' m'; $('btnPlay').textContent = save.unlocked > 1 ? 'Lanjut Level ' + save.unlocked : 'Mulai Berlari'; setH('menuCoins', coinHTML + ' ' + save.coins); }

/* ---------- gambar ---------- */
const tmp = M4.ident(), vp = M4.ident(), mA = M4.ident(), mB = M4.ident(), mC = M4.ident();
const clouds = Array.from({ length: 12 }, (_, i) => ({ m: cloudM[i % 6], x: -320 + rnd() * 560, y: 75 + rnd() * 50, z: rnd() * 1400, s: 1.2 + rnd() * 1.6, sp: 0.4 + rnd() * 0.8 }));
const birds = Array.from({ length: 14 }, (_, i) => ({ cx: -30 - rnd() * 90, cz: -60 - i * 28, y: 14 + rnd() * 26, r: 14 + rnd() * 26, w: 0.25 + rnd() * 0.25, ph: rnd() * 6.28, fs: 6 + rnd() * 3 }));
const boats = [{ m: 0, x: -70, z: 100, v: -3.5 }, { m: 1, x: -42, z: -220, v: -5 }, { m: 0, x: -130, z: -480, v: 2.5 }, { m: 1, x: -95, z: -700, v: 6 }, { m: 1, x: -60, z: 300, v: -2 }];
const wrap = (z, c, period, back) => z - period * Math.floor((z - (c - back)) / period);

/* langit dihaluskan: tidak pernah melompat saat level / waktu berganti */
let pal = null, frameDt = 0.016;
function smoothPal(t, dt) {
  const k = 1 - Math.exp(-dt * 3);
  if (!pal) { pal = { top: t.top.slice(), bot: t.bot.slice(), amb: t.amb.slice(), sc: t.sc.slice(), el: t.el, si: t.si }; return pal; }
  for (const key of ['top', 'bot', 'amb', 'sc']) for (let i = 0; i < 3; i++) pal[key][i] = lerp(pal[key][i], t[key][i], k);
  pal.el = lerp(pal.el, t.el, k); pal.si = lerp(pal.si, t.si, k); return pal;
}
const sstep = (a, b, x) => { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };

/* gambar pelari: tiap bagian punya sendi sendiri */
const MH = M4.ident(), M1 = M4.ident(), M2 = M4.ident();
function drawRunner(x, y, z, ry, lean, amp, tilt, alpha) {
  const s = Math.sin(ph), c = Math.cos(ph), A = 1 - air, ch = cheer, ls = landS * (1 - ch);
  /* fase lompat: 0 = naik, 0.5 = puncak, 1 = turun (mengikuti kecepatan vertikal) */
  const q = clamp(0.5 - vy / 18, 0, 1), J = (r, f) => lerp(r, f, q);
  const lerpA = (run, jmp, chr) => lerp(lerp(run, jmp, air), chr, ch);
  const twist = 0.09 * s * amp * A * (1 - ch);
  const dip = (-0.1 * amp * A + Math.abs(s) * 0.06 * amp * A) * (1 - ch) - 0.2 * ls;
  M4.model(mA, x, y + dip * 0.88, z, ry + twist, -0.14 * amp * A - tilt - 0.2 * ls, -lean, 0.88);
  const base = mA;
  const thL = lerpA(0.15 + 0.7 * s * amp, J(0.95, 0.5), 0.05) + 0.45 * ls, thR = lerpA(0.15 - 0.7 * s * amp, J(-0.5, -0.12), -0.05) + 0.3 * ls;
  const knL = lerpA(-(0.2 + 1.25 * Math.max(0, c) * amp), J(-1.25, -0.35), -0.1) - 0.7 * ls, knR = lerpA(-(0.2 + 1.25 * Math.max(0, -c) * amp), J(-1.0, -0.55), -0.1) - 0.7 * ls;
  const auL = lerpA(-0.95 * s * amp, J(2.6, 1.5), 2.9), auR = lerpA(0.95 * s * amp, J(2.3, 1.2), 2.7);
  const afL = lerpA(1.15 + 0.25 * s * amp, J(0.35, 0.7), 0.2), afR = lerpA(1.15 - 0.25 * s * amp, J(0.5, 0.8), 0.2);
  const o = alpha == null ? null : { alpha };
  R.draw(runnerM.torso, base, o); M4.model(tmp, 0, 1.6, 0, -twist * 0.8, 0.12 * ls, 0, 1); R.draw(runnerM.head, M4.mul(base, tmp, MH), o);
  const limb = (up, fo, jx, jy, a1, a2) => { M4.model(mB, jx, jy, 0, 0, a1, 0, 1); M4.mul(base, mB, M1); R.draw(up, M1, o); M4.model(mC, 0, jy === 1.02 ? -0.5 : -0.34, 0, 0, a2, 0, 1); R.draw(fo, M4.mul(M1, mC, M2), o); };
  limb(runnerM.legU, runnerM.legF, -0.13, 1.02, thL, knL); limb(runnerM.legU, runnerM.legF, 0.13, 1.02, thR, knR);
  if (runnerM.wingR) {
    const fl = state === 'celebrate' ? Math.sin(time * 12) * 0.5 + 0.3 : (air > 0.5 ? Math.sin(time * 16) * 0.45 + 0.25 : Math.sin(time * 7) * 0.22 + 0.12);
    M4.model(mB, 0.14, 1.42, 0.2, 0, 0.12, fl, 1); R.draw(runnerM.wingR, M4.mul(base, mB, M1), o);
    M4.model(mB, -0.14, 1.42, 0.2, 0, 0.12, -fl, 1); R.draw(runnerM.wingL, M4.mul(base, mB, M1), o);
  }
  limb(runnerM.armU, runnerM.armF, -0.33, 1.52, auL, afL); limb(runnerM.armU, runnerM.armF, 0.33, 1.52, auR, afR);
}

function render() {
  R.resize(resCap);
  const prog = (L + (state === 'play' || state === 'celebrate' ? clamp(lvDist / levelLen(L), 0, 1) : 0)) * 0.1 + 0.07;
  const p = smoothPal(palette(prog % 1), frameDt);
  const night = clamp((0.28 - (p.top[0] + p.top[1] + p.top[2]) / 3) / 0.18, 0, 1), moonK = sstep(0.25, 0.65, night);
  R.fog = p.bot.slice(); R.amb = p.amb; R.sunI = p.si;
  const sunDir = [0.55, p.el, -0.65], sl = Math.hypot(...sunDir); const sd = sunDir.map(v => v / sl);
  R.sun = [sd[0], Math.max(sd[1], 0.35), sd[2]]; { const l = Math.hypot(...R.sun); R.sun = R.sun.map(v => v / l); }
  const sh = shake * 0.12 * (Math.random() - 0.5);
  camX = lerp(camX, px, 1 - Math.exp(-frameDt * 6.3));
  let cam = [camX * 0.7 + sh, (R.aspect < 1 ? 5 : 4.3) + py * 0.3 + sh, pz + 8.8], look = [camX * 0.35, 1.7, pz - 13];
  let fov = (R.aspect < 1 ? 76 : 52) + (state === 'play' ? clamp((speed - 15) * 0.12, 0, 12) : 0);
  if (state === 'menu') { cam[0] = -2.5 + Math.sin(time * 0.2) * 1.4; cam[1] = 3.4; cam[2] = pz + 8; look[0] = -2; look[1] = 3.2; look[2] = pz - 30; }
  let spinY = 0;
  if (state === 'shop') {
    const land = R.aspect > 1.1; fov = 42; const dist = 4.6, th = Math.tan(fov * Math.PI / 360);
    const dy = land ? 0 : 0.5 * dist * th, dx = land ? 0.5 * dist * th * R.aspect : 0;
    cam = [dx, 1.05, pz + dist]; look = [dx, 1.05 - dy, pz]; spinY = time * 0.9 + 0.4;
  }
  const proj = M4.persp(fov * Math.PI / 180, R.aspect, 1.6, 900);
  const view = M4.lookAt(cam, look, [state === 'play' ? lean * 0.06 : 0, 1, 0]); const VP = M4.mul(proj, view);
  R.begin(VP, cam);
  // langit, matahari/bulan, bintang
  M4.model(tmp, cam[0], cam[1], cam[2]); R.sky(skyM, tmp, p.top, p.bot);
  if (night > 0.05) { R.draw(starM, tmp, { unlit: true, alpha: night, tint: [1, 1, 1] }); }
  const sy = cam[1] + lerp(sd[1], 0.6, moonK) * 250, sx = cam[0] + sd[0] * 250, sz = cam[2] + sd[2] * 250;
  M4.model(tmp, sx, sy, sz, 0, 0, 0, lerp(1.3, 0.7, moonK));
  if (sy > cam[1] - 20) R.draw(sunM, tmp, { unlit: true, tint: [lerp(p.sc[0], 0.85, moonK), lerp(p.sc[1] * 0.95, 0.9, moonK), lerp(p.sc[2] * 0.8, 1, moonK)] });
  // awan
  for (const c of clouds) {
    const cz = wrap(c.z, pz, 1500, 900), cx = ((c.x + time * c.sp * 2 + 400) % 800) - 400 - 20;
    M4.model(tmp, cx, c.y, cz, 0, 0, 0, c.s); R.draw(c.m, tmp, { unlit: true, tint: [lerp(1, 0.25, night) * (0.8 + p.sc[0] * 0.2), lerp(1, 0.28, night) * (0.78 + p.sc[1] * 0.22), lerp(1, 0.4, night) * (0.7 + p.sc[2] * 0.3)] });
  }
  // sungai
  M4.model(tmp, 0, 0, Math.round(pz / 50) * 50); R.draw(waterM, tmp, { water: true });
  // tepian jauh
  const fi = Math.floor(-pz / 150);
  for (let i = fi - 1; i <= fi + 4; i++) { M4.model(tmp, 0, 0, -i * 150, 0, 0, 0, 1); R.draw(farV[((i % 3) + 3) % 3], tmp); }
  // jembatan (tiap 900 m)
  const bi = Math.floor(-pz / 900);
  for (let i = bi - 1; i <= bi + 1; i++) { const bz = -380 - i * 900; if (Math.abs(bz - pz) < 750) { M4.model(tmp, 0, 0, bz); R.draw(bridgeM, tmp); } }
  // jalan
  const ci = Math.floor(-pz / CHUNK_L);
  for (let i = ci - 1; i <= ci + 10; i++) {
    const v = roadV[((i * 7) % 4 + 4) % 4]; M4.model(tmp, 0, 0, -i * CHUNK_L); R.draw(v.m, tmp); R.draw(v.p, tmp, { offset: -1 }); R.draw(v.k, tmp, { offset: -3 });
    if (night > 0.05) R.draw(v.g, tmp, { unlit: true, alpha: Math.min(0.8, night), tint: [1, 0.92, 0.7] });
  }
  // gapura garis finis: tanda akhir tiap level
  if (state === 'play') { const rem = levelLen(L) - lvDist; if (rem < 640) { M4.model(tmp, 0, 0, pz - rem); R.draw(gateM, tmp); } }
  gates = gates.filter(z => z < pz + 60); for (const z of gates) { M4.model(tmp, 0, 0, z); R.draw(gateM, tmp); }
  // patung Pesut (tiap 420 m)
  const pi = Math.floor(-pz / 420);
  for (let i = pi - 1; i <= pi + 1; i++) { const zz = -260 - i * 420; M4.model(tmp, 10.5, 0, zz, Math.PI / 2, 0, 0, 1.3); R.draw(pesutM, tmp); }
  // perahu
  for (const b of boats) { const z = wrap(b.z + b.v * time, pz, 900, 560); M4.model(tmp, b.x, -4.4 + Math.sin(time + b.x) * 0.05, z, b.v > 0 ? 0 : Math.PI); R.draw(boatM[b.m], tmp); }
  // burung
  for (const b of birds) {
    const a = time * b.w + b.ph, dz = wrap(b.cz, pz, 500, 300);
    const x = b.cx + Math.cos(a) * b.r, z = dz + Math.sin(a) * b.r * 1.4 - 40, dxv = -Math.sin(a) * b.r * b.w, dzv = Math.cos(a) * b.r * 1.4 * b.w;
    M4.model(tmp, x, b.y + Math.sin(a * 2) * 1.5, z, Math.atan2(-dxv, -dzv), 0, -0.25, 1.1); R.draw(birdM[Math.floor(time * b.fs + b.ph) & 3], tmp);
  }
  // objek di jalan
  for (const o of obs) {
    if (o.z > pz + 14 || o.z < pz - SPAWN_AHEAD - 20) continue;
    if (o.t === 'car') { M4.model(tmp, o.x, 0, o.z, 0); R.draw(carM[o.k], tmp); }
    else if (o.t === 'bar') { M4.model(tmp, o.x, 0, o.z); R.draw(barrierM, tmp); }
    else { M4.model(tmp, o.x, 0, o.z); R.draw(coneM, tmp); }
  }
  // koin: terang (tidak terpengaruh gelap malam), berputar, dengan cahaya di belakangnya
  for (const c of coins) {
    if (c.z < pz - SPAWN_AHEAD - 20 || c.z > pz + 14) continue;
    const yy = c.y + Math.sin(time * 3 + c.ph) * 0.1;
    M4.model(tmp, c.x, yy, c.z, time * 3 + c.ph, 0, 0, 1.15); R.draw(coinM, tmp, { unlit: true, tint: [1, 1, 1], noCull: true });
  }
  // pemain
  const blink = blinkOn && inv > 0 && Math.floor(time * 14) % 2 === 0;
  M4.model(tmp, px, 0.03, pz, 0, 0, 0, 1); R.draw(shadowM, tmp, { unlit: true, alpha: 0.18 - Math.min(py, 2) * 0.05, tint: [1, 1, 1], offset: -5 });
  if (!blink) {
    const amp = state === 'play' || state === 'menu' || state === 'celebrate' || state === 'shop' ? clamp(speed / 12, 0.4, 1) : 0.4;
    const ry = state === 'shop' ? spinY + Math.PI : (state === 'play' ? yaw : 0);
    drawRunner(px, py, pz, ry, state === 'shop' ? 0 : lean, state === 'shop' ? 0.55 : amp, state === 'play' ? clamp(vy * 0.012, -0.12, 0.12) : 0);
  }
}

/* ---------- loop ---------- */
let last = performance.now();
/* resolusi adaptif: jaga frame time tetap rendah (target refresh layar, termasuk 90/120 Hz) */
let resMax = Math.min(window.devicePixelRatio || 1, 2), resCap = Math.min(resMax, 1.6), emaDt = 1 / 60, bestDt = 1, nFrames = 0, goodRun = 0, noRaiseT = 0;
function adaptRes(raw) {
  if (raw > 0.1) return; // tab disembunyikan / jeda panjang: abaikan
  emaDt += (raw - emaDt) * 0.06; nFrames++; noRaiseT = Math.max(0, noRaiseT - raw);
  if (nFrames > 90) bestDt = Math.min(bestDt * 1.0003, emaDt);
  if (nFrames % 45) return;
  if (nFrames > 90 && emaDt > bestDt * 1.45 && resCap > 0.8) { resCap = Math.max(0.8, resCap * 0.9); goodRun = 0; noRaiseT = 12; }
  else if (emaDt < bestDt * 1.12 && resCap < resMax && noRaiseT <= 0) { if (++goodRun >= 6) { resCap = Math.min(resMax, resCap * 1.08); goodRun = 0; } }
  else goodRun = 0;
}
function loop(now) {
  const raw = (now - last) / 1000, dt = Math.min(raw, 0.05); last = now; frameDt = dt;
  adaptRes(raw); update(dt); render(); requestAnimationFrame(loop);
}
setMuted(muted); loadTrack(trackI, false); updateMenu();
window.__game = { get state() { return state; }, start: startGame, setLevel(n) { L = n; }, R, shop: openShop, complete: completeLevel, hit: loseHeart, get hp() { return hp; }, get L() { return L; } };
requestAnimationFrame(loop);
})();
