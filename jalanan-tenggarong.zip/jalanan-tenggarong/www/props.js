/* Langit, awan, burung, kendaraan, koin, perahu, patung Pesut */
'use strict';

function buildSkyDome() {
  const mb = new MeshBuilder(), R = 300, S = 16, T = 8;
  const P = (a, b) => [Math.cos(a) * Math.sin(b) * R, Math.cos(b) * R, Math.sin(a) * Math.sin(b) * R];
  for (let i = 0; i < S; i++) for (let j = 0; j < T; j++) {
    const a0 = i / S * Math.PI * 2, a1 = (i + 1) / S * Math.PI * 2, b0 = j / T * Math.PI * 0.5, b1 = (j + 1) / T * Math.PI * 0.5;
    mb.quad(P(a0, b0), P(a1, b0), P(a1, b1), P(a0, b1), [1, 1, 1]);
  }
  for (let j = 0; j < T; j++) for (let i = 0; i < S; i++) { // belahan bawah (kabut horizon)
    const a0 = i / S * Math.PI * 2, a1 = (i + 1) / S * Math.PI * 2;
    mb.quad(P(a0, Math.PI * 0.5), P(a1, Math.PI * 0.5), P(a1, Math.PI * 0.62), P(a0, Math.PI * 0.62), [1, 1, 1]);
  }
  return mb;
}

function buildSun() { const mb = new MeshBuilder(); mb.sphere(0, 0, 0, 14, 14, 14, [1, 0.95, 0.8], 8); return mb; }

function buildStars() {
  const mb = new MeshBuilder(), r = rng(99);
  for (let i = 0; i < 160; i++) {
    const a = r() * Math.PI * 2, b = Math.acos(0.12 + r() * 0.88), R = 280, s = 0.7 + r() * 1.1;
    const x = Math.cos(a) * Math.sin(b) * R, y = Math.cos(b) * R, z = Math.sin(a) * Math.sin(b) * R;
    mb.quad([x - s, y - s, z], [x + s, y - s, z], [x + s, y + s, z], [x - s, y + s, z], [1, 1, 0.92]);
    mb.quad([x - s, y + s, z], [x + s, y + s, z], [x + s, y - s, z], [x - s, y - s, z], [1, 1, 0.92]);
  }
  return mb;
}

function buildCloud(seed) {
  const r = rng(seed * 101 + 7), mb = new MeshBuilder(), n = 6 + ((r() * 5) | 0), len = 14 + r() * 12;
  for (let i = 0; i < n; i++) {
    const t = i / (n - 1) - 0.5, rr = 6 + r() * 5 - Math.abs(t) * 5;
    mb.sphere(t * len, (r() - 0.3) * 2 + (1 - Math.abs(t) * 2) * 2, (r() - 0.5) * 8, rr * 1.2, rr * 0.55, rr * 0.9, [1, 1, 1], 6);
  }
  mb.box(0, -3.2, 0, len * 1.2, 0.1, 10, [0.8, 0.82, 0.9]);
  return mb;
}

/* burung: 4 pose kepakan, satu draw per burung */
function buildBird(pose) {
  const mb = new MeshBuilder(), c = [0.15, 0.15, 0.18], wc = [0.25, 0.25, 0.3];
  mb.sphere(0, 0, 0, 0.35, 0.25, 0.8, c, 4);
  mb.tri([0.0, 0.05, -0.8], [-0.12, 0, -1.3], [0.12, 0, -1.3], c, [0, 1, 0]);
  const ang = [0.6, 0.1, -0.55, 0.1][pose], w = 2.2;
  for (const s of [-1, 1]) {
    const tipX = s * Math.cos(ang) * w, tipY = Math.sin(ang) * w;
    const a = [0, 0.05, 0.5], b = [0, 0.05, -0.5], t1 = [tipX, tipY, -0.2], t2 = [tipX * 0.95, tipY * 0.95 - 0.05, 0.35];
    const q = s > 0 ? [a, t2, t1, b] : [a, b, t1, t2];
    mb.quad(q[0], q[1], q[2], q[3], wc, [0, 1, 0]); mb.quad(q[3], q[2], q[1], q[0], wc, [0, -1, 0]);
  }
  return mb;
}

/* motor + pengendara (pemain) */
function buildPlayer() {
  const mb = new MeshBuilder(), body = [0.9, 0.25, 0.2], dark = [0.15, 0.15, 0.17], skin = [0.85, 0.62, 0.45], shirt = [0.95, 0.75, 0.2];
  mb.box(0, 0, 0.95, 0.16, 0.7, 0.7, dark); mb.box(0, 0, -0.95, 0.2, 0.7, 0.7, dark); // ban
  mb.box(0, 0.3, 0, 0.5, 0.45, 1.5, body);
  mb.box(0, 0.75, -0.1, 0.46, 0.14, 1.0, dark);
  mb.box(0, 0.75, 0.75, 0.42, 0.55, 0.3, body);
  mb.box(0, 0.95, 0.72, 0.9, 0.08, 0.1, dark); // stang
  mb.box(0, 0.5, 0.95, 0.15, 0.55, 0.1, [0.7, 0.7, 0.72]);
  mb.box(0, 0.35, -0.9, 0.35, 0.15, 0.4, [0.8, 0.1, 0.1]);
  mb.box(0, 0.9, -0.15, 0.5, 0.7, 0.4, shirt); // badan
  mb.box(-0.14, 0.55, 0.15, 0.17, 0.45, 0.5, [0.2, 0.3, 0.55]); mb.box(0.14, 0.55, 0.15, 0.17, 0.45, 0.5, [0.2, 0.3, 0.55]);
  mb.box(-0.36, 1.2, 0.35, 0.12, 0.12, 0.7, shirt); mb.box(0.36, 1.2, 0.35, 0.12, 0.12, 0.7, shirt);
  mb.sphere(0, 1.8, -0.1, 0.28, 0.3, 0.28, skin, 6);
  mb.sphere(0, 1.88, -0.1, 0.34, 0.26, 0.34, [0.2, 0.55, 0.75], 6); // helm
  return mb;
}


function buildCar(kind) {
  const mb = new MeshBuilder();
  const cols = [[0.95, 0.8, 0.15], [0.2, 0.5, 0.85], [0.85, 0.25, 0.25], [0.95, 0.95, 0.95]];
  const c = cols[kind % 4], dark = [0.12, 0.12, 0.14], glass = [0.45, 0.65, 0.8];
  if (kind === 4) { // truk batu bara
    mb.box(0, 0.5, 0.2, 2.0, 1.2, 5, [0.2, 0.55, 0.3]); mb.box(0, 0.5, -2.4, 2.0, 1.9, 1.6, [0.9, 0.9, 0.9]);
    mb.box(0, 1.7, 0.3, 1.8, 0.9, 4.2, [0.1, 0.1, 0.1]); mb.box(0, 1.4, -3.15, 1.8, 0.7, 0.05, glass);
  } else {
    mb.box(0, 0.45, 0, 1.9, 0.8, 4.0, c);
    mb.box(0, 1.2, 0.1, 1.7, 0.8, 2.6, c);
    mb.box(0, 1.35, -1.22, 1.6, 0.55, 0.06, glass); mb.box(0, 1.35, 1.42, 1.6, 0.55, 0.06, glass);
    mb.box(-0.86, 1.3, 0.1, 0.06, 0.55, 2.2, glass); mb.box(0.86, 1.3, 0.1, 0.06, 0.55, 2.2, glass);
    mb.box(0, 0.2, -2.0, 1.9, 0.18, 0.1, dark);
  }
  for (const x of [-0.95, 0.95]) for (const z of [-1.2, 1.3]) mb.box(x, 0, z, 0.22, 0.65, 0.65, dark);
  mb.box(-0.6, 0.55, -2.01, 0.4, 0.18, 0.04, [1, 0.95, 0.7]); mb.box(0.6, 0.55, -2.01, 0.4, 0.18, 0.04, [1, 0.95, 0.7]);
  return mb;
}

function buildBarrier() {
  const mb = new MeshBuilder();
  for (const x of [-0.95, 0.95]) mb.box(x, 0, 0, 0.12, 1.0, 0.12, [0.3, 0.3, 0.32]);
  for (let i = 0; i < 8; i++) mb.box(-0.9 + i * 0.25 + 0.125, 0.5, 0, 0.25, 0.35, 0.1, i % 2 ? [0.95, 0.95, 0.95] : [0.95, 0.35, 0.15]);
  return mb;
}

function buildCone() { const mb = new MeshBuilder(); mb.box(0, 0, 0, 0.7, 0.08, 0.7, [0.2, 0.2, 0.2]); mb.cyl(0, 0.08, 0, 0.3, 0.05, 0.85, [1, 0.5, 0.12], 8); mb.cyl(0, 0.45, 0, 0.19, 0.15, 0.12, [1, 1, 1], 8); return mb; }

function buildCoin() { const mb = new MeshBuilder(); mb.cyl(0, -0.04, 0, 0.42, 0.42, 0.08, [1, 0.8, 0.2], 10); mb.cyl(0, -0.05, 0, 0.28, 0.28, 0.1, [1, 0.95, 0.55], 10); return mb; }

function buildBoat(kind) {
  const mb = new MeshBuilder();
  if (kind === 0) { // tongkang batu bara + tugboat
    mb.box(0, -0.2, 0, 7, 1.6, 26, [0.3, 0.3, 0.32]); mb.box(0, 1.4, 0, 6.4, 1.6, 24, [0.12, 0.12, 0.12]);
    mb.box(0, -0.2, 17, 4.6, 1.4, 8, [0.8, 0.2, 0.2]); mb.box(0, 1.2, 18, 3, 1.8, 3.6, [0.95, 0.95, 0.95]); mb.box(0, 3, 18, 3.2, 0.2, 4, [0.3, 0.3, 0.35]);
  } else { // perahu ketinting
    mb.box(0, 0, 0, 1.4, 0.7, 7, [0.55, 0.4, 0.25]); mb.box(0, 0.7, 0.5, 1.7, 0.1, 3.5, [0.2, 0.55, 0.65]);
    mb.box(0, 0.7, 3.4, 0.2, 0.9, 0.2, [0.2, 0.2, 0.2]);
  }
  return mb;
}

/* Patung Pesut Mahakam (lumba-lumba air tawar) di taman kanan */
function buildPesut() {
  const mb = new MeshBuilder(), g = [0.72, 0.74, 0.78];
  mb.cyl(0, 0, 0, 1.8, 1.6, 0.9, [0.65, 0.6, 0.5], 10);
  mb.cyl(0, 0.9, 0, 0.35, 0.3, 1.8, [0.7, 0.7, 0.72], 8);
  for (const zz of [-0.9, 0.9]) {
    for (let i = 0; i < 8; i++) {
      const u0 = i / 8, u1 = (i + 1) / 8, f = u => [-1.8 + 3.6 * u, 2.6 + Math.sin(u * Math.PI) * 2.3, zz];
      mb.beam(f(u0), f(u1), 0.75 - u0 * 0.4, g);
    }
    mb.sphere(1.9, 2.5, zz, 0.55, 0.45, 0.4, g, 5);
    mb.tri([-1.8, 2.5, zz], [-2.5, 2.1, zz], [-2.3, 3.1, zz], g, [0, 0, 1]);
  }
  return mb;
}
