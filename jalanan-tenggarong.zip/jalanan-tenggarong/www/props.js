/* Langit, awan, burung, kendaraan, koin, perahu, patung Pesut */
'use strict';

function buildSkyDome() {
  const mb = new MeshBuilder(), R = 300, S = 16, T = 8;
  const P = (a, b) => [Math.cos(a) * Math.sin(b) * R, Math.cos(b) * R, Math.sin(a) * Math.sin(b) * R];
  for (let i = 0; i < S; i++) for (let j = 0; j < T; j++) {
    const a0 = i / S * Math.PI * 2, a1 = (i + 1) / S * Math.PI * 2, b0 = j / T * Math.PI * 0.5, b1 = (j + 1) / T * Math.PI * 0.5;
    mb.quad(P(a0, b0), P(a1, b0), P(a1, b1), P(a0, b1), [1, 1, 1]);
  }
  for (let j = 0; j < T; j++) for (let i = 0; i < S; i++) { // belahan bawah (kabut horizon)
    const a0 = i / S * Math.PI * 2, a1 = (i + 1) / S * Math.PI * 2;
    mb.quad(P(a0, Math.PI * 0.5), P(a1, Math.PI * 0.5), P(a1, Math.PI * 0.62), P(a0, Math.PI * 0.62), [1, 1, 1]);
  }
  return mb;
}

function buildSun() { const mb = new MeshBuilder(); mb.sphere(0, 0, 0, 14, 14, 14, [1, 0.95, 0.8], 8); return mb; }

function buildStars() {
  const mb = new MeshBuilder(), r = rng(99);
  for (let i = 0; i < 160; i++) {
    const a = r() * Math.PI * 2, b = Math.acos(0.12 + r() * 0.88), R = 280, s = 0.7 + r() * 1.1;
    const x = Math.cos(a) * Math.sin(b) * R, y = Math.cos(b) * R, z = Math.sin(a) * Math.sin(b) * R;
    mb.quad([x - s, y - s, z], [x + s, y - s, z], [x + s, y + s, z], [x - s, y + s, z], [1, 1, 0.92]);
    mb.quad([x - s, y + s, z], [x + s, y + s, z], [x + s, y - s, z], [x - s, y - s, z], [1, 1, 0.92]);
  }
  return mb;
}

function buildCloud(seed) {
  const r = rng(seed * 101 + 7), mb = new MeshBuilder(), n = 6 + ((r() * 5) | 0), len = 14 + r() * 12;
  for (let i = 0; i < n; i++) {
    const t = i / (n - 1) - 0.5, rr = 6 + r() * 5 - Math.abs(t) * 5;
    mb.sphere(t * len, (r() - 0.3) * 2 + (1 - Math.abs(t) * 2) * 2, (r() - 0.5) * 8, rr * 1.2, rr * 0.55, rr * 0.9, [1, 1, 1], 6);
  }
  mb.box(0, -3.2, 0, len * 1.2, 0.1, 10, [0.8, 0.82, 0.9]);
  return mb;
}

/* burung: 4 pose kepakan, satu draw per burung */
function buildBird(pose) {
  const mb = new MeshBuilder(), c = [0.15, 0.15, 0.18], wc = [0.25, 0.25, 0.3];
  mb.sphere(0, 0, 0, 0.35, 0.25, 0.8, c, 4);
  mb.tri([0.0, 0.05, -0.8], [-0.12, 0, -1.3], [0.12, 0, -1.3], c, [0, 1, 0]);
  const ang = [0.6, 0.1, -0.55, 0.1][pose], w = 2.2;
  for (const s of [-1, 1]) {
    const tipX = s * Math.cos(ang) * w, tipY = Math.sin(ang) * w;
    const a = [0, 0.05, 0.5], b = [0, 0.05, -0.5], t1 = [tipX, tipY, -0.2], t2 = [tipX * 0.95, tipY * 0.95 - 0.05, 0.35];
    const q = s > 0 ? [a, t2, t1, b] : [a, b, t1, t2];
    mb.quad(q[0], q[1], q[2], q[3], wc, [0, 1, 0]); mb.quad(q[3], q[2], q[1], q[0], wc, [0, -1, 0]);
  }
  return mb;
}

function buildCar(kind) {
  const mb = new MeshBuilder();
  const cols = [[0.95, 0.8, 0.15], [0.2, 0.5, 0.85], [0.85, 0.25, 0.25], [0.95, 0.95, 0.95]];
  const c = cols[kind % 4], dark = [0.12, 0.12, 0.14], glass = [0.45, 0.65, 0.8];
  if (kind === 4) { // truk batu bara
    mb.box(0, 0.5, 0.2, 2.0, 1.2, 5, [0.2, 0.55, 0.3]); mb.box(0, 0.5, -2.4, 2.0, 1.9, 1.6, [0.9, 0.9, 0.9]);
    mb.box(0, 1.7, 0.3, 1.8, 0.9, 4.2, [0.1, 0.1, 0.1]); mb.box(0, 1.4, -3.15, 1.8, 0.7, 0.05, glass);
  } else {
    mb.box(0, 0.45, 0, 1.9, 0.8, 4.0, c);
    mb.box(0, 1.2, 0.1, 1.7, 0.8, 2.6, c);
    mb.box(0, 1.35, -1.22, 1.6, 0.55, 0.06, glass); mb.box(0, 1.35, 1.42, 1.6, 0.55, 0.06, glass);
    mb.box(-0.86, 1.3, 0.1, 0.06, 0.55, 2.2, glass); mb.box(0.86, 1.3, 0.1, 0.06, 0.55, 2.2, glass);
    mb.box(0, 0.2, -2.0, 1.9, 0.18, 0.1, dark);
  }
  for (const x of [-0.95, 0.95]) for (const z of [-1.2, 1.3]) mb.box(x, 0, z, 0.22, 0.65, 0.65, dark);
  mb.box(-0.6, 0.55, -2.01, 0.4, 0.18, 0.04, [1, 0.95, 0.7]); mb.box(0.6, 0.55, -2.01, 0.4, 0.18, 0.04, [1, 0.95, 0.7]);
  return mb;
}

function buildBarrier() {
  const mb = new MeshBuilder();
  for (const x of [-0.95, 0.95]) mb.box(x, 0, 0, 0.12, 1.0, 0.12, [0.3, 0.3, 0.32]);
  for (let i = 0; i < 8; i++) mb.box(-0.9 + i * 0.25 + 0.125, 0.5, 0, 0.25, 0.35, 0.1, i % 2 ? [0.95, 0.95, 0.95] : [0.95, 0.35, 0.15]);
  return mb;
}

function buildCone() { const mb = new MeshBuilder(); mb.box(0, 0, 0, 0.7, 0.08, 0.7, [0.2, 0.2, 0.2]); mb.cyl(0, 0.08, 0, 0.3, 0.05, 0.85, [1, 0.5, 0.12], 8); mb.cyl(0, 0.45, 0, 0.19, 0.15, 0.12, [1, 1, 1], 8); return mb; }

function buildBoat(kind) {
  const mb = new MeshBuilder();
  if (kind === 0) { // tongkang batu bara + tugboat
    mb.box(0, -0.2, 0, 7, 1.6, 26, [0.3, 0.3, 0.32]); mb.box(0, 1.4, 0, 6.4, 1.6, 24, [0.12, 0.12, 0.12]);
    mb.box(0, -0.2, 17, 4.6, 1.4, 8, [0.8, 0.2, 0.2]); mb.box(0, 1.2, 18, 3, 1.8, 3.6, [0.95, 0.95, 0.95]); mb.box(0, 3, 18, 3.2, 0.2, 4, [0.3, 0.3, 0.35]);
  } else { // perahu ketinting
    mb.box(0, 0, 0, 1.4, 0.7, 7, [0.55, 0.4, 0.25]); mb.box(0, 0.7, 0.5, 1.7, 0.1, 3.5, [0.2, 0.55, 0.65]);
    mb.box(0, 0.7, 3.4, 0.2, 0.9, 0.2, [0.2, 0.2, 0.2]);
  }
  return mb;
}

/* Patung Pesut Mahakam (lumba-lumba air tawar) di taman kanan */
function buildPesut() {
  const mb = new MeshBuilder(), g = [0.72, 0.74, 0.78];
  mb.cyl(0, 0, 0, 1.8, 1.6, 0.9, [0.65, 0.6, 0.5], 10);
  mb.cyl(0, 0.9, 0, 0.35, 0.3, 1.8, [0.7, 0.7, 0.72], 8);
  for (const zz of [-0.9, 0.9]) {
    for (let i = 0; i < 8; i++) {
      const u0 = i / 8, u1 = (i + 1) / 8, f = u => [-1.8 + 3.6 * u, 2.6 + Math.sin(u * Math.PI) * 2.3, zz];
      mb.beam(f(u0), f(u1), 0.75 - u0 * 0.4, g);
    }
    mb.sphere(1.9, 2.5, zz, 0.55, 0.45, 0.4, g, 5);
    mb.tri([-1.8, 2.5, zz], [-2.5, 2.1, zz], [-2.3, 3.1, zz], g, [0, 0, 1]);
  }
  return mb;
}


/* ---------- koin: dua sisi, tepi tebal, bintang di tengah (selalu jelas terlihat) ---------- */
function buildCoin() {
  const mb = new MeshBuilder(), N = 14, T = 0.09;
  const rim = [0.78, 0.45, 0.05], rim2 = [1, 0.62, 0.1], face = [1, 0.86, 0.25], hi = [1, 0.97, 0.7], star = [0.85, 0.5, 0.05];
  const P = (r, k, z) => { const a = k / N * Math.PI * 2; return [Math.cos(a) * r, Math.sin(a) * r, z]; };
  for (const sd of [1, -1]) {
    const z = T * sd, z2 = (T + 0.025) * sd, nrm = [0, 0, sd];
    for (let k = 0; k < N; k++) {
      const A = k, B = k + 1;
      // cincin luar
      const q = (r0, r1, zz, col) => { if (sd > 0) mb.quad(P(r0, A, zz), P(r1, A, zz), P(r1, B, zz), P(r0, B, zz), col, nrm); else mb.quad(P(r0, B, zz), P(r1, B, zz), P(r1, A, zz), P(r0, A, zz), col, nrm); };
      q(0.62, 0.5, z, rim2); q(0.5, 0.0001, z2, k % 2 ? face : hi);
    }
    // bintang kecil di tengah
    for (let k = 0; k < 5; k++) {
      const a0 = k / 5 * Math.PI * 2 + Math.PI / 2, a1 = (k + 0.5) / 5 * Math.PI * 2 + Math.PI / 2, a2 = (k + 1) / 5 * Math.PI * 2 + Math.PI / 2, zz = (T + 0.05) * sd;
      const tp = [Math.cos(a0) * 0.36, Math.sin(a0) * 0.36, zz], m1 = [Math.cos(a1) * 0.15, Math.sin(a1) * 0.15, zz], m2 = [Math.cos(a2 - 0.0) * 0.15, Math.sin(a2) * 0.15, zz];
      const c0 = [0, 0, zz];
      if (sd > 0) { mb.tri(c0, m1, tp, star, nrm); mb.tri(c0, tp, [Math.cos(a0 - Math.PI / 5) * 0.15, Math.sin(a0 - Math.PI / 5) * 0.15, zz], star, nrm); }
      else { mb.tri(c0, tp, m1, star, nrm); mb.tri(c0, [Math.cos(a0 - Math.PI / 5) * 0.15, Math.sin(a0 - Math.PI / 5) * 0.15, zz], tp, star, nrm); }
    }
  }
  // sisi tepi koin
  for (let k = 0; k < N; k++) {
    const a = k / N * Math.PI * 2, b = (k + 1) / N * Math.PI * 2, r = 0.62, n = [Math.cos((a + b) / 2), Math.sin((a + b) / 2), 0];
    mb.quad([Math.cos(a) * r, Math.sin(a) * r, T], [Math.cos(a) * r, Math.sin(a) * r, -T], [Math.cos(b) * r, Math.sin(b) * r, -T], [Math.cos(b) * r, Math.sin(b) * r, T], rim, n);
  }
  return mb;
}

/* ---------- katalog toko kosmetik ---------- */
const SHOP = {
  helm: [
    { n: 'Tanpa Helm', p: 0, c: [0.15, 0.12, 0.1] },
    { n: 'Topi Merah', p: 150, c: [0.85, 0.2, 0.18] },
    { n: 'Helm Proyek', p: 300, c: [0.97, 0.78, 0.1] },
    { n: 'Tanjak Kutai', p: 600, c: [0.62, 0.1, 0.12] },
    { n: 'Mahkota Emas', p: 1200, c: [1, 0.8, 0.25] }],
  baju: [
    { n: 'Kaos Kuning', p: 0, c: [0.95, 0.76, 0.2] },
    { n: 'Kaos Merah', p: 120, c: [0.86, 0.2, 0.2] },
    { n: 'Jersey Biru', p: 250, c: [0.15, 0.4, 0.86], c2: [1, 1, 1] },
    { n: 'Batik Kutai', p: 500, c: [0.42, 0.2, 0.1], c2: [0.96, 0.76, 0.25] },
    { n: 'Baju Sultan', p: 1000, c: [0.96, 0.72, 0.15], c2: [0.75, 0.1, 0.12], long: true }],
  jaket: [
    { n: 'Tanpa Jaket', p: 0, c: [0.75, 0.75, 0.78] },
    { n: 'Hoodie Abu', p: 200, c: [0.55, 0.57, 0.62], c2: [0.9, 0.9, 0.92], hood: true },
    { n: 'Jaket Jeans', p: 350, c: [0.25, 0.42, 0.7], c2: [0.9, 0.7, 0.3] },
    { n: 'Jaket Hijau', p: 450, c: [0.1, 0.6, 0.3], c2: [0.97, 0.97, 0.97] },
    { n: 'Jaket Kulit', p: 700, c: [0.14, 0.12, 0.13], c2: [0.8, 0.8, 0.85], collar: true }],
  celana: [
    { n: 'Celana Biru', p: 0, c: [0.2, 0.3, 0.58] },
    { n: 'Celana Hitam', p: 100, c: [0.13, 0.13, 0.16] },
    { n: 'Celana Hijau', p: 200, c: [0.18, 0.52, 0.3] },
    { n: 'Pendek Merah', p: 350, c: [0.86, 0.2, 0.2], short: true },
    { n: 'Celana Emas', p: 900, c: [0.96, 0.76, 0.2] }],
  sepatu: [
    { n: 'Sepatu Putih', p: 0, c: [0.95, 0.95, 0.95] },
    { n: 'Sepatu Merah', p: 100, c: [0.86, 0.15, 0.15] },
    { n: 'Sepatu Hitam', p: 150, c: [0.14, 0.14, 0.17] },
    { n: 'Sepatu Biru', p: 250, c: [0.2, 0.46, 0.92] },
    { n: 'Sepatu Emas', p: 700, c: [0.98, 0.78, 0.2] }],
  sayap: [
    { n: 'Tanpa Sayap', p: 0, c: [0.75, 0.75, 0.78] },
    { n: 'Sayap Malaikat', p: 500, c: [0.97, 0.97, 1], c2: [0.8, 0.9, 1] },
    { n: 'Sayap Kelelawar', p: 700, c: [0.35, 0.12, 0.45], c2: [0.15, 0.05, 0.2] },
    { n: 'Sayap Enggang', p: 900, c: [0.1, 0.1, 0.12], c2: [0.97, 0.97, 0.97] },
    { n: 'Sayap Emas', p: 1300, c: [1, 0.8, 0.25], c2: [1, 0.55, 0.1] }]
};

/* ---------- pelari: bagian-bagian terpisah supaya bisa digerakkan (kepala, badan, lengan, tungkai) ---------- */
function buildRunner(eq) {
  const skin = [0.86, 0.63, 0.46], dark = [0.1, 0.09, 0.1];
  const helm = SHOP.helm[eq.helm] || SHOP.helm[0], baju = SHOP.baju[eq.baju] || SHOP.baju[0],
    cel = SHOP.celana[eq.celana] || SHOP.celana[0], sep = SHOP.sepatu[eq.sepatu] || SHOP.sepatu[0];
  const out = {}, jak = eq.jaket > 0 ? SHOP.jaket[eq.jaket] : null;
  /* kepala (titik asal = leher) */
  let h = new MeshBuilder();
  h.sphere(0, 0.23, 0, 0.2, 0.23, 0.21, skin, 8);
  h.box(-0.075, 0.26, -0.185, 0.05, 0.06, 0.03, dark); h.box(0.075, 0.26, -0.185, 0.05, 0.06, 0.03, dark);
  h.box(0, 0.15, -0.195, 0.12, 0.035, 0.03, [0.65, 0.18, 0.18]);
  h.box(-0.14, 0.19, -0.17, 0.05, 0.04, 0.03, [0.95, 0.5, 0.45]); h.box(0.14, 0.19, -0.17, 0.05, 0.04, 0.03, [0.95, 0.5, 0.45]);
  if (eq.helm === 0) h.sphere(0, 0.3, 0.04, 0.215, 0.19, 0.2, dark, 8);
  else if (eq.helm === 1) { h.cyl(0, 0.3, 0, 0.23, 0.2, 0.15, helm.c, 10); h.box(0, 0.34, -0.27, 0.34, 0.035, 0.22, helm.c); h.box(0, 0.45, 0, 0.05, 0.03, 0.05, [1, 1, 1]); }
  else if (eq.helm === 2) { h.sphere(0, 0.3, 0, 0.255, 0.2, 0.255, helm.c, 8); h.cyl(0, 0.29, 0, 0.31, 0.31, 0.03, helm.c, 12); h.box(0, 0.47, 0, 0.07, 0.04, 0.42, [0.9, 0.65, 0.05]); }
  else if (eq.helm === 3) { h.cyl(0, 0.3, 0, 0.24, 0.22, 0.1, helm.c, 10); h.box(0, 0.37, -0.01, 0.5, 0.025, 0.02, [1, 0.8, 0.25]); h.cyl(0, 0.4, 0, 0.22, 0.1, 0.1, [0.75, 0.14, 0.14], 10); h.cyl(0.02, 0.5, 0.05, 0.12, 0.01, 0.24, [0.85, 0.2, 0.18], 8); h.box(0, 0.33, -0.235, 0.12, 0.05, 0.02, [1, 0.8, 0.25]); }
  else { h.cyl(0, 0.36, 0, 0.23, 0.23, 0.1, helm.c, 12); for (let k = 0; k < 6; k++) { const a = k / 6 * Math.PI * 2; h.cyl(Math.cos(a) * 0.19, 0.46, Math.sin(a) * 0.19, 0.055, 0, 0.17, helm.c, 4); } h.sphere(0, 0.41, -0.235, 0.04, 0.04, 0.03, [0.9, 0.1, 0.15], 5); }
  out.head = h;
  /* badan */
  const t = new MeshBuilder();
  t.box(0, 0.98, 0, 0.5, 0.64, 0.3, baju.c);
  t.box(0, 1.5, 0, 0.5, 0.1, 0.3, baju.c); t.box(0, 1.58, 0, 0.14, 0.06, 0.14, skin);
  if (baju.c2) {
    if (eq.baju === 2) { t.box(0, 1.2, -0.152, 0.5, 0.08, 0.02, baju.c2); t.box(0, 1.05, -0.152, 0.5, 0.08, 0.02, baju.c2); t.box(0, 1.2, 0.152, 0.5, 0.08, 0.02, baju.c2); t.box(0, 1.05, 0.152, 0.5, 0.08, 0.02, baju.c2); }
    else if (eq.baju === 3) { for (let k = 0; k < 4; k++) { t.box(0, 1.04 + k * 0.14, -0.152, 0.46, 0.05, 0.02, baju.c2); t.box(-0.13, 1.1 + k * 0.14, -0.153, 0.07, 0.07, 0.02, baju.c2); t.box(0.13, 1.1 + k * 0.14, -0.153, 0.07, 0.07, 0.02, baju.c2); t.box(0, 1.04 + k * 0.14, 0.152, 0.46, 0.05, 0.02, baju.c2); } }
    else { t.box(0, 0.98, -0.152, 0.09, 0.64, 0.02, baju.c2); t.box(0, 1.5, -0.152, 0.4, 0.1, 0.02, baju.c2); t.box(0, 0.98, 0.152, 0.5, 0.06, 0.02, [1, 0.88, 0.4]); }
  }
  t.box(0, 0.93, 0, 0.52, 0.07, 0.32, cel.c); // pinggang celana
  if (jak) {
    t.box(0, 0.9, 0, 0.58, 0.72, 0.36, jak.c); t.box(0, 1.5, 0, 0.58, 0.12, 0.36, jak.c);
    t.box(0, 0.9, -0.182, 0.05, 0.72, 0.02, jak.c2); t.box(0, 0.88, 0, 0.6, 0.06, 0.38, jak.c2); // resleting & ujung jaket
    if (jak.hood) { t.sphere(0, 1.62, 0.17, 0.26, 0.2, 0.18, jak.c, 6); t.box(-0.06, 1.2, -0.185, 0.03, 0.22, 0.02, jak.c2); t.box(0.06, 1.2, -0.185, 0.03, 0.22, 0.02, jak.c2); }
    else if (jak.collar) { t.box(-0.13, 1.6, -0.1, 0.16, 0.1, 0.2, jak.c2); t.box(0.13, 1.6, -0.1, 0.16, 0.1, 0.2, jak.c2); }
    else { t.box(0, 1.6, 0, 0.36, 0.09, 0.3, jak.c); t.box(0, 1.2, -0.185, 0.46, 0.04, 0.02, jak.c2); }
  }
  out.torso = t;
  /* lengan (titik asal = bahu / siku) */
  const au = new MeshBuilder(), af = new MeshBuilder(), sc = jak ? jak.c : (baju.long ? baju.c : skin), uc = jak ? jak.c : baju.c;
  au.box(0, -0.33, 0, jak ? 0.19 : 0.16, 0.36, jak ? 0.19 : 0.16, uc); au.sphere(0, 0, 0, 0.11, 0.11, 0.11, uc, 5);
  af.box(0, -0.31, 0, jak ? 0.16 : 0.13, 0.31, jak ? 0.16 : 0.13, sc); af.sphere(0, -0.34, 0, 0.085, 0.085, 0.085, skin, 5);
  if (jak) af.box(0, -0.3, 0, 0.17, 0.05, 0.17, jak.c2); else if (baju.long && baju.c2) af.box(0, -0.3, 0, 0.145, 0.05, 0.145, baju.c2);
  out.armU = au; out.armF = af;
  /* tungkai (titik asal = pinggul / lutut) */
  const lu = new MeshBuilder(), lf = new MeshBuilder(), sk = cel.short ? skin : cel.c;
  lu.box(0, -0.5, 0, 0.21, 0.52, 0.23, cel.c);
  lf.box(0, -0.43, 0, 0.17, 0.43, 0.19, cel.short ? skin : cel.c);
  if (cel.short) lf.box(0, -0.2, 0, 0.19, 0.05, 0.21, [1, 1, 1]); // kaus kaki
  lf.box(0, -0.54, -0.06, 0.2, 0.12, 0.4, sep.c); lf.box(0, -0.56, -0.06, 0.21, 0.04, 0.41, [0.95, 0.95, 0.95]);
  out.legU = lu; out.legF = lf;
  if (eq.sayap > 0) {
    const w = SHOP.sayap[eq.sayap];
    for (const s of [1, -1]) {
      const m = new MeshBuilder();
      for (let layer = 0; layer < 2; layer++) for (let k = 0; k < 5; k++) {
        const a = 0.75 - k * 0.34 + layer * 0.12, len = (1.55 - k * 0.12) * (layer ? 0.7 : 1), col = layer ? w.c : (k > 2 ? w.c2 : w.c);
        const tipC = layer ? w.c : (k % 2 ? w.c2 : w.c);
        m.beam([0, layer * -0.05, 0], [Math.cos(a) * len * s, Math.sin(a) * len, 0], layer ? 0.2 : 0.16, col);
        m.beam([Math.cos(a) * len * 0.62 * s, Math.sin(a) * len * 0.62, 0], [Math.cos(a) * len * s, Math.sin(a) * len, 0], layer ? 0.21 : 0.17, tipC);
      }
      m.sphere(0, 0, 0, 0.16, 0.2, 0.14, w.c2, 5);
      out[s > 0 ? 'wingR' : 'wingL'] = m;
    }
  }
  return out;
}


/* ---------- gapura garis finis (penanda akhir tiap level) ---------- */
function buildGate() {
  const mb = new MeshBuilder(), gold = [1, 0.8, 0.25], red = [0.78, 0.15, 0.15], W = [0.97, 0.97, 0.97], K = [0.08, 0.08, 0.1];
  for (const s of [-1, 1]) {
    mb.box(s * 5.1, 0, 0, 0.9, 7.2, 0.9, red); mb.box(s * 5.1, 0, 0, 1.15, 0.5, 1.15, gold); mb.box(s * 5.1, 6.6, 0, 1.15, 0.4, 1.15, gold);
    mb.sphere(s * 5.1, 7.5, 0, 0.45, 0.55, 0.45, gold, 6);
    for (let k = 0; k < 6; k++) mb.box(s * 5.1, 0.5 + k * 1.0, 0, 0.95, 0.5, 0.95, k % 2 ? W : K); // belang hitam-putih
  }
  const cols = 16, cw = 10.2 / cols, rows = 3, ch = 0.55;
  for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) mb.box(-5.1 + cw * (c + 0.5), 5.6 + r * ch, 0, cw, ch, 0.5, (r + c) % 2 ? K : W);
  mb.box(0, 7.25, 0, 11.2, 0.35, 0.7, gold); mb.box(0, 5.4, 0, 11.2, 0.2, 0.7, red);
  mb.box(0, 7.6, 0, 3.2, 0.3, 0.5, red);
  // garis finis di aspal (kotak-kotak hitam putih)
  const n = 16, w = 8.4 / n;
  for (let r = 0; r < 3; r++) for (let c = 0; c < n; c++) { const x0 = -4.2 + c * w, z0 = -0.9 + r * 0.6; mb.quad([x0, 0.08, z0 + 0.6], [x0 + w, 0.08, z0 + 0.6], [x0 + w, 0.08, z0], [x0, 0.08, z0], (r + c) % 2 ? K : W, [0, 1, 0]); }
  return mb;
}
